# The Only One - Sức Khỏe Sinh Viên

Ứng dụng theo dõi sức khỏe, thực hiện thử thách, nhiệm vụ và tích điểm đổi quà dành cho sinh viên. Dự án được xây dựng bằng React, Vite, Tailwind CSS và TypeScript.

## 🛠️ Công nghệ sử dụng

- **Frontend Framework**: React 19 + TypeScript
- **Build Tool**: Vite
- **Styling**: Tailwind CSS v4
- **Animations**: Motion (framer-motion)
- **Icons**: Lucide React

---

## 🚀 Hướng dẫn cài đặt và chạy trên máy cục bộ (Local)

Để chạy dự án này trên máy của bạn (ví dụ: dùng VS Code), hãy làm theo các bước dưới đây:

### Bước 1: Cài đặt Node.js
Đảm bảo máy tính của bạn đã cài đặt **Node.js** (Khuyên dùng phiên bản LTS mới nhất - từ v18 trở lên).
- Tải về tại: [nodejs.org](https://nodejs.org/)

### Bước 2: Tải mã nguồn và mở bằng VS Code
1. Tải file ZIP dự án về máy và giải nén.
2. Mở ứng dụng **VS Code**.
3. Chọn **File** -> **Open Folder...** và trỏ đến thư mục dự án vừa giải nén.

### Bước 3: Cài đặt các thư viện phụ thuộc (`node_modules`)
Mở cửa sổ Terminal trong VS Code (phím tắt ``Ctrl + ` `` hoặc `Cmd + \`` trên Mac, hoặc vào menu **Terminal** -> **New Terminal**) và chạy câu lệnh sau để cài đặt toàn bộ thư viện:

```bash
npm install
```

> Thao tác này sẽ tự động tải các thư viện cần thiết và tạo thư mục `node_modules` trên máy của bạn (đây là lý do tại sao thư mục này tự xuất hiện khi tải hoặc khởi chạy dự án cục bộ).

### Bước 4: Khởi chạy dự án ở chế độ Phát triển (Development)
Chạy lệnh sau trong Terminal để khởi động máy chủ cục bộ:

```bash
npm run dev
```

Sau khi chạy thành công, Terminal sẽ hiển thị đường dẫn cục bộ, thường là:
- `http://localhost:3000` hoặc `http://localhost:5173`

Hãy mở trình duyệt và truy cập địa chỉ trên để xem ứng dụng chạy thực tế.

---

## 📦 Đóng gói sản phẩm (Build Production)

Khi bạn muốn tối ưu hóa mã nguồn để tải lên máy chủ thật hoặc bàn giao sản phẩm:

```bash
npm run build
```

Kết quả sau khi build thành công sẽ nằm trong thư mục `dist`. Bạn chỉ cần đưa nội dung thư mục này lên các dịch vụ hosting tĩnh (như Netlify, Vercel, GitHub Pages, chia sẻ host...) là ứng dụng có thể hoạt động trực tuyến.

---

## 📂 Cấu trúc thư mục chính

```text
├── src/
│   ├── components/   # Các thành phần giao diện nhỏ (Chức năng, Thử thách, Đổi quà, v.v.)
│   ├── App.tsx       # Thành phần gốc điều hướng chính ứng dụng
│   ├── index.css     # Định dạng phong cách phong phú bằng Tailwind CSS
│   ├── main.tsx      # Điểm khởi chạy của dự án React
│   ├── types.ts      # Định nghĩa các kiểu dữ liệu và Interface TypeScript
│   └── utils.ts      # Các hàm bổ trợ dùng chung
├── index.html        # Trang HTML chính cấu cấu trúc ứng dụng
├── package.json      # File quản lý phiên bản và thư viện cần có
├── tsconfig.json     # Cấu hình kiểm tra cú pháp TypeScript
└── vite.config.ts    # Cấu hình công cụ đóng gói Vite
```
