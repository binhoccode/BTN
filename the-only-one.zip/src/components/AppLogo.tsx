import React from "react";

interface AppLogoProps {
  className?: string;
  size?: number;
}

export default function AppLogo({ className = "w-10 h-10", size = 40 }: AppLogoProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`${className} transition-transform hover:scale-110 active:scale-95 duration-300`}
    >
      <defs>
        {/* Neon premium linear gradient for the heart outline and elements */}
        <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#F43F5E" /> {/* Vibrant Rose */}
          <stop offset="50%" stopColor="#EC4899" /> {/* Pink */}
          <stop offset="100%" stopColor="#8B5CF6" /> {/* Violet */}
        </linearGradient>
        
        {/* Inside glowing gradient for the number 1 */}
        <linearGradient id="oneGradient" x1="40" y1="40" x2="60" y2="65" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#22D3EE" /> {/* Bright Cyan */}
          <stop offset="100%" stopColor="#06B6D4" /> {/* Cyan Medium */}
        </linearGradient>

        {/* Drop shadow and glow filters */}
        <filter id="logoGlow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="3.5" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
      </defs>

      {/* Cyberpunk circular badge helper */}
      <circle
        cx="50"
        cy="50"
        r="47"
        fill="#09090B"
        stroke="url(#logoGradient)"
        strokeWidth="2.5"
        className="opacity-90"
      />

      {/* Concentric subtle tech rings */}
      <circle
        cx="50"
        cy="50"
        r="42"
        stroke="#27272A"
        strokeWidth="1"
        strokeDasharray="3 3"
        className="opacity-40"
      />

      {/* Solid filled soft backdrop of the heart */}
      <path
        d="M 50 28 
           C 38 12, 14 18, 14 44 
           C 14 66, 50 88, 50 88 
           C 50 88, 86 66, 86 44 
           C 86 18, 62 12, 50 28 
           Z"
        fill="url(#logoGradient)"
        opacity="0.12"
      />

      {/* 
        PREMIUM STYLIZED HEART OUTLINE SVG
        Symmetric cyber-heart design with precision anchors:
      */}
      <path
        d="M 50 28 
           C 38 12, 14 18, 14 44 
           C 14 66, 50 88, 50 88 
           C 50 88, 86 66, 86 44 
           C 86 18, 62 12, 50 28 
           Z"
        fill="none"
        stroke="url(#logoGradient)"
        strokeWidth="4.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        filter="url(#logoGlow)"
      />

      {/* 
        The Number "1" - Standing bold and bright directly in the center of the heart!
      */}
      <g filter="url(#logoGlow)">
        {/* Base support bar of Number 1 */}
        <path
          d="M 42 64 L 58 64"
          stroke="url(#oneGradient)"
          strokeWidth="3.5"
          strokeLinecap="round"
        />
        {/* Main tall stem of Number 1 */}
        <path
          d="M 50 64 L 50 41"
          stroke="url(#oneGradient)"
          strokeWidth="4.5"
          strokeLinecap="round"
        />
        {/* Top left hook of Number 1 */}
        <path
          d="M 50 41 C 48 42.5, 44 43, 42 43"
          stroke="url(#oneGradient)"
          strokeWidth="3.5"
          strokeLinecap="round"
        />
      </g>
    </svg>
  );
}
