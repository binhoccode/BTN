/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Ticket, Flame, Gift, ArrowLeft, Check, Copy, AlertCircle, PlayCircle, ShieldCheck, Award } from "lucide-react";
import { AppState, Reward } from "../types";
import { generatePhoneCardCode } from "../utils";

interface RewardShopProps {
  state: AppState;
  onNavigate: (tab: string) => void;
  onClaimReward: (rewardId: string, telco: string, pin: string, serial: string) => void;
  onReviveStreak: () => void;
}

export default function RewardShop({ state, onNavigate, onClaimReward, onReviveStreak }: RewardShopProps) {
  const { streakManager, rewards } = state;

  const [selectedTelco, setSelectedTelco] = useState<{ [key: string]: string }>({});
  const [activeClaimId, setActiveClaimId] = useState<string | null>(null);
  const [isWatchingAd, setIsWatchingAd] = useState(false);
  const [adCountdown, setAdCountdown] = useState(5);
  const [showToast, setShowToast] = useState<string | null>(null);
  const [activeAdSponsor, setActiveAdSponsor] = useState<number | null>(null);

  const adSponsors = [
    {
      title: "Hảo Hảo Hạnh Phúc",
      slogan: "Mì ăn liền vị Tôm Chua Cay quốc dân hỗ trợ thâu đêm giải đề!",
      prizes: "Mì ăn liền Hảo Hảo - Người bạn đồng hành ấm bụng của mọi thế hệ sinh viên."
    },
    {
      title: "Cà phê Gác Mái",
      slogan: "Cú đêm ôn thi không lo sập nguồn - Học bài bao chill quận 10",
      prizes: "Giảm ngay 20% cho sinh viên mang theo thẻ sinh viên chính chủ!"
    },
    {
      title: "The Only One Sức Khỏe Vàng",
      slogan: "Bản lĩnh độc bản - Rèn giũa thói quen ngủ sớm rạng ngời",
      prizes: "Giữ kỷ luật hôm nay, rước thẻ cào miễn phí ngày mai."
    }
  ];

  // Copy helper
  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setShowToast(`Đã sao chép ${label}!`);
    setTimeout(() => setShowToast(null), 2500);
  };

  // Launch simulated ad watcher
  const handleStartWatchingAd = () => {
    if (streakManager.reviveTicketsLeft <= 0) {
      alert("Bạn đã dùng hết cả 3 lượt hồi sinh của tháng này rồi bạn ơi! Giờ phải nghiêm túc làm lại từ đầu thôi.");
      return;
    }
    setIsWatchingAd(true);
    setAdCountdown(5);
    setActiveAdSponsor(Math.floor(Math.random() * adSponsors.length));
    
    // Countdown ticks
    const interval = setInterval(() => {
      setAdCountdown(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  // Finish ad watching and restore streak
  const handleCompleteAdWatch = () => {
    setIsWatchingAd(false);
    onReviveStreak();
    setShowToast("🎉 Hồi sinh chuỗi Streak thành công!");
    setTimeout(() => setShowToast(null), 3000);
  };

  const startClaimFlow = (rewardId: string) => {
    setActiveClaimId(rewardId);
    if (!selectedTelco[rewardId]) {
      setSelectedTelco(prev => ({ ...prev, [rewardId]: "Viettel" }));
    }
  };

  const handleClaimConfirm = (reward: Reward) => {
    const telco = selectedTelco[reward.rewardId] || "Viettel";
    const codes = generatePhoneCardCode(telco);
    onClaimReward(reward.rewardId, telco, codes.pin, codes.serial);
    setActiveClaimId(null);
    setShowToast(`Đã nhận thẻ cào ${telco} ${reward.rewardValue.toLocaleString()}đ Về hòm thư bạn!`);
    setTimeout(() => setShowToast(null), 3000);
  };

  return (
    <div className="space-y-6 max-w-lg mx-auto pb-12 relative">
      {/* Head line with Navigation Back */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => onNavigate("home")}
          className="p-2 bg-zinc-900 border border-zinc-800 rounded-xl text-zinc-400 hover:text-white transition active:scale-95 flex items-center justify-center"
          title="Về Trang Chủ"
          id="btn-back-home"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h2 className="text-lg font-bold text-zinc-100 flex items-center gap-1.5 leading-none">
            🎁 KHO ĐỔI THƯỞNG
          </h2>
          <span className="text-[11px] text-zinc-500 font-medium">Kỷ luật bền bỉ, nhận thẻ liền tay</span>
        </div>
      </div>

      {/* Streak Points Indicator */}
      <div className="bg-gradient-to-br from-zinc-900 to-zinc-950 p-5 rounded-3xl border border-zinc-800/80 shadow-lg flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-amber-500/15 p-3 rounded-2xl border border-amber-500/20 text-amber-500">
            <Flame className="w-6 h-6 fill-amber-500/10" />
          </div>
          <div>
            <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider block">ĐỒNG STREAK HIỆN CÓ</span>
            <span className="text-xl font-black text-zinc-100">{streakManager.currentStreak} Ngày</span>
          </div>
        </div>
        <div className="text-right w-1/2">
          <div className="text-xs text-zinc-400 font-semibold">Tích lũy từng ngày khỏe mạnh</div>
          <div className="text-[10px] text-zinc-500 mt-1">Đạt mốc 50 ngày nhận thẻ cào 10K đầu tiên!</div>
        </div>
      </div>

      {/* Rewards Milestones Stack */}
      <div className="space-y-4">
        <h4 className="text-xs uppercase font-extrabold tracking-widest text-zinc-400 px-1">
          🎟️ Thẻ cào điện thoại bạn đã tích lũy
        </h4>

        {rewards.map((reward) => {
          const isEligible = streakManager.currentStreak >= reward.rewardMilestone;
          const isClaimed = reward.isClaimed;
          const daysLeftToMilestone = reward.rewardMilestone - streakManager.currentStreak;

          return (
            <div
              key={reward.rewardId}
              className={`p-5 rounded-3xl border transition-all ${
                isClaimed 
                  ? "bg-zinc-950/40 border-zinc-900" 
                  : isEligible 
                    ? "bg-gradient-to-r from-zinc-900 via-amber-500/5 to-zinc-900 border-amber-500/30 shadow-indigo-505/5" 
                    : "bg-zinc-900/10 border-zinc-800/50"
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className={`p-3 rounded-2xl border ${
                    isClaimed 
                      ? "bg-zinc-900/50 text-zinc-650 border-zinc-800" 
                      : isEligible 
                        ? "bg-amber-500/20 text-amber-500 border-amber-500/30 animate-pulse" 
                        : "bg-zinc-800 text-zinc-500 border-zinc-700/60"
                  }`}>
                    <Gift className="w-5 h-5" />
                  </div>
                  <div>
                    <h5 className="text-xs font-mono font-black text-amber-500 uppercase">
                      Mốc {reward.rewardMilestone} ngày streak
                    </h5>
                    <h3 className="text-sm font-bold text-zinc-200 mt-0.5">
                      Thẻ điện thoại trị giá {reward.rewardValue.toLocaleString()}đ
                    </h3>
                  </div>
                </div>

                <div className="text-right">
                  {isClaimed ? (
                    <span className="text-[10px] font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full uppercase">
                      ĐÃ NHẬN
                    </span>
                  ) : isEligible ? (
                    <span className="text-[10px] font-mono font-bold bg-amber-500 text-zinc-950 px-2 py-0.5 rounded-full uppercase">
                      ĐỦ ĐIỀU KIỆN
                    </span>
                  ) : (
                    <span className="text-[10px] font-mono font-bold bg-zinc-800 text-zinc-500 border border-zinc-700 px-2 py-0.5 rounded-full uppercase">
                      KHOÁ
                    </span>
                  )}
                </div>
              </div>

              {/* Action area based on eligibility */}
              {isClaimed ? (
                /* Claimed Details Layout */
                <div className="mt-4 pt-4 border-t border-zinc-800/80 bg-zinc-950/80 p-4 rounded-2xl space-y-3 font-mono text-xs">
                  <div className="flex justify-between items-center text-zinc-500 border-b border-zinc-900 pb-2">
                    <span>Cổng Nhà Mạng:</span>
                    <span className="font-bold text-zinc-300 uppercase">{reward.claimTelco}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-zinc-500">Mã cào PIN:</span>
                    <div className="flex items-center gap-1">
                      <span className="font-black text-amber-500">{reward.claimCode}</span>
                      <button
                        onClick={() => handleCopy(reward.claimCode || "", "Mã nạp")}
                        className="p-1 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded transition"
                        title="Sao chép"
                        id={`btn-copy-pin-${reward.rewardId}`}
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-zinc-550">Số Seri:</span>
                    <div className="flex items-center gap-1">
                      <span className="font-semibold text-zinc-300">{reward.claimSerial}</span>
                      <button
                        onClick={() => handleCopy(reward.claimSerial || "", "Số seri")}
                        className="p-1 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded transition"
                        title="Sao chép"
                        id={`btn-copy-serial-${reward.rewardId}`}
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                  <div className="text-[9px] text-zinc-600 text-center uppercase tracking-wider pt-2 border-t border-zinc-900/60 flex items-center justify-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" /> Hệ thống bảo mật The Only One cấp phát thực
                  </div>
                </div>
              ) : isEligible ? (
                /* Select Carrier & Claim */
                <div className="mt-4 pt-4 border-t border-zinc-800/80 space-y-3">
                  {activeClaimId === reward.rewardId ? (
                    <div className="space-y-3 bg-zinc-950/40 p-3 rounded-2xl border border-zinc-800">
                      <label className="text-xs text-zinc-400 font-semibold block">CHỌN NHÀ MẠNG BỒ MUỐN NẠP:</label>
                      <div className="grid grid-cols-3 gap-2">
                        {["Viettel", "Vinaphone", "Mobifone"].map((telco) => (
                          <button
                            key={telco}
                            onClick={() => setSelectedTelco(prev => ({ ...prev, [reward.rewardId]: telco }))}
                            className={`py-2 text-xs font-bold rounded-xl border text-center transition ${
                              selectedTelco[reward.rewardId] === telco
                                ? "border-amber-500 bg-amber-500/10 text-amber-500 font-black"
                                : "border-zinc-800 bg-zinc-900 text-zinc-400 hover:bg-zinc-800"
                            }`}
                            id={`telco-choice-${reward.rewardId}-${telco}`}
                          >
                            {telco}
                          </button>
                        ))}
                      </div>
                      <div className="flex items-center gap-2 pt-1">
                        <button
                          onClick={() => setActiveClaimId(null)}
                          className="flex-1 py-2 rounded-xl border border-zinc-800 bg-zinc-900 hover:bg-zinc-800 text-xs font-semibold text-zinc-400 transition"
                          id={`btn-cancel-claim-${reward.rewardId}`}
                        >
                          Hủy bỏ
                        </button>
                        <button
                          onClick={() => handleClaimConfirm(reward)}
                          className="flex-1 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-xs font-extrabold text-zinc-950 hover:scale-105 transition active:scale-95 flex items-center justify-center gap-1.5"
                          id={`btn-confirm-claim-${reward.rewardId}`}
                        >
                          Xác nhận nhận
                        </button>
                      </div>
                    </div>
                  ) : (
                    <button
                      onClick={() => startClaimFlow(reward.rewardId)}
                      className="w-full py-2.5 bg-amber-500 hover:bg-amber-600 text-zinc-950 hover:scale-101 text-center font-black text-xs rounded-xl shadow-lg transition active:scale-98 flex items-center justify-center gap-1.5 uppercase"
                      id={`btn-trigger-claim-${reward.rewardId}`}
                    >
                      🎁 ĐỔI THỂ CÀO {reward.rewardValue.toLocaleString()}đ NGAY
                    </button>
                  )}
                </div>
              ) : (
                /* Locked Hint */
                <p className="mt-3 text-[11px] text-zinc-500 font-mono font-medium flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5 text-zinc-600" /> 
                  Status: [ KHÓA - Cần thêm {daysLeftToMilestone} ngày streak nữa ]
                </p>
              )}
            </div>
          );
        })}
      </div>

      {/* Revive Broken Streak Section */}
      <div className="bg-zinc-950 p-6 rounded-3xl border border-zinc-800/80 shadow-md">
        <div className="text-center space-y-1">
          <h3 className="text-sm font-black text-red-500 flex items-center justify-center gap-1.5 uppercase tracking-wide">
            💀 BẠN BỊ ĐỨT STREAK?
          </h3>
          <p className="text-xs text-zinc-400">
            Lỡ ngủ muộn hoặc bận thi cả ngày quên tích? Đừng lo lắng!
          </p>
        </div>

        {/* Ticket remaining and Ads trigger */}
        <div className="mt-5 p-4 bg-zinc-900/30 rounded-2xl border border-zinc-800/8c space-y-4">
          <div className="flex justify-between items-center text-xs font-semibold">
            <span className="text-zinc-400">Vé cứu sinh tháng 5:</span>
            <span className="font-mono text-zinc-200 bg-zinc-900 px-2 py-1 rounded-lg border border-zinc-800">
              🎟️ {streakManager.reviveTicketsLeft} / 3 Lượt
            </span>
          </div>

          {streakManager.reviveTicketsLeft > 0 ? (
            <button
              onClick={handleStartWatchingAd}
              className="w-full bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-550 py-3.5 px-4 rounded-xl font-black text-xs text-white shadow-xl shadow-red-950/20 active:scale-95 transition flex items-center justify-center gap-1.5 uppercase"
              id="btn-trigger-ad-revive"
            >
              <PlayCircle className="w-4 h-4 fill-white text-red-600 animate-pulse" /> 
              📺 XEM QUẢNG CÁO HỒI SINH STREAK
            </button>
          ) : (
            <div className="w-full text-center py-3 bg-zinc-800/50 rounded-xl border border-zinc-700/40 text-xs font-bold text-zinc-550">
              ĐÃ DÙNG HẾT VÉ CỨU SINH THÁNG NÀY 🔒
            </div>
          )}

          <p className="text-[10px] text-zinc-500 text-center block">
            Giới hạn: Mỗi tháng bạn chỉ được khôi phục 3 lần bằng vé cứu sinh thôi nhé.
          </p>
        </div>
      </div>

      {/* Simulated Advertisement Watching fullscreen overlay */}
      <AnimatePresence>
        {isWatchingAd && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/95 flex flex-col items-center justify-center p-6 text-center"
          >
            {/* Ad Container Box */}
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="max-w-md w-full bg-zinc-900 border border-zinc-700 rounded-3xl p-6 shadow-2xl relative overflow-hidden"
            >
              {/* Top ticker badge */}
              <div className="absolute top-4 right-4 bg-zinc-950/80 border border-zinc-800 px-3.5 py-1 rounded-full text-xs font-mono font-bold text-amber-400">
                Quảng cáo kết thúc sau: {adCountdown}s
              </div>

              {/* Sponsor visuals */}
              <div className="my-8 space-y-4">
                <span className="inline-flex py-1 px-2.5 rounded bg-zinc-850 text-zinc-400 font-mono text-[9px] uppercase tracking-widest">
                  NHÀ TÀI TRỢ CHÍNH THỨC
                </span>
                
                {activeAdSponsor !== null && (
                  <div className="space-y-4 mx-2">
                    <div className="w-20 h-20 bg-amber-500/10 rounded-2xl mx-auto flex items-center justify-center border border-amber-500/20 text-amber-500 animate-bounce">
                      <Award className="w-10 h-10 stroke-[2]" />
                    </div>
                    <div>
                      <h4 className="text-xl font-extrabold text-zinc-100 uppercase">
                        {adSponsors[activeAdSponsor].title}
                      </h4>
                      <p className="text-sm font-semibold text-amber-400 mt-1">
                        &ldquo;{adSponsors[activeAdSponsor].slogan}&rdquo;
                      </p>
                    </div>
                    <div className="p-3 bg-zinc-950 rounded-xl border border-zinc-800 text-xs text-zinc-400">
                      {adSponsors[activeAdSponsor].prizes}
                    </div>
                  </div>
                )}
              </div>

              {/* Video track simulate visual */}
              <div className="h-2 bg-zinc-800 rounded-full overflow-hidden w-full">
                <motion.div
                  initial={{ width: "0%" }}
                  animate={{ width: "100%" }}
                  transition={{ duration: 5, ease: "linear" }}
                  className="h-full bg-gradient-to-r from-red-600 via-amber-500 to-emerald-500"
                />
              </div>

              {/* Confirm / skip button */}
              <div className="mt-6 flex justify-center">
                {adCountdown === 0 ? (
                  <button
                    onClick={handleCompleteAdWatch}
                    className="px-6 py-2.5 bg-emerald-500 hover:bg-emerald-600 font-black text-xs text-zinc-950 rounded-xl transition cursor-pointer flex items-center gap-1 uppercase"
                    id="btn-complete-ad"
                  >
                    🚀 NHẬN VÉ CỨU SINH & HỒI SINH СHUỖI
                  </button>
                ) : (
                  <button
                    disabled
                    className="px-6 py-2.5 bg-zinc-800 text-zinc-500 font-bold text-xs rounded-xl cursor-not-allowed border border-zinc-700/60 font-mono uppercase"
                  >
                    Xem hết QC để nhận cứu sinh ({adCountdown}s)
                  </button>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Copy notification toast alert */}
      <AnimatePresence>
        {showToast && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-24 left-1/2 -translate-x-1/2 z-40 bg-zinc-900 border border-amber-500/40 text-amber-500 font-semibold px-4 py-2.5 rounded-xl shadow-xl text-xs text-center min-w-[200px]"
          >
            {showToast}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
