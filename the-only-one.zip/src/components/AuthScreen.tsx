/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Sparkles, User, Mail, ShieldAlert, ArrowRight, UserPlus, LogIn, Flame, CheckCircle, Smartphone, Trash2 } from "lucide-react";
import { loadRegisteredAccounts, saveRegisteredAccounts, createStateForUser, AccountCredentials } from "../utils";
import AppLogo from "./AppLogo";

interface AuthScreenProps {
  onLoginSuccess: (credentials: AccountCredentials, isNew: boolean) => void;
}

export default function AuthScreen({ onLoginSuccess }: AuthScreenProps) {
  const [isRegistering, setIsRegistering] = useState<boolean>(false);
  const [accounts, setAccounts] = useState<Record<string, AccountCredentials>>({});
  const [accountToDelete, setAccountToDelete] = useState<AccountCredentials | null>(null);
  
  // Form input fields
  const [username, setUsername] = useState<string>("");
  const [fullName, setFullName] = useState<string>("");
  const [email, setEmail] = useState<string>("");
  const [errorMsg, setErrorMsg] = useState<string>("");
  const [successMsg, setSuccessMsg] = useState<string>("");



  // Load account registry on mount
  useEffect(() => {
    setAccounts(loadRegisteredAccounts());
  }, []);

  const handleDeleteAccount = (usernameToDelete: string) => {
    const updated = { ...accounts };
    delete updated[usernameToDelete];
    saveRegisteredAccounts(updated);
    setAccounts(updated);
    
    // Clear independent cached user state from localStorage
    localStorage.removeItem(`the_only_one_user_state_${usernameToDelete}`);
    
    setSuccessMsg(`Đã xóa tài khoản @${usernameToDelete} thành công!`);
    setAccountToDelete(null);
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");
    
    if (!username.trim()) {
      setErrorMsg("Vui lòng điền tên đăng nhập bạn nhé!");
      return;
    }

    const cleanUsername = username.trim().toLowerCase();
    const existing = accounts[cleanUsername];

    if (existing) {
      setSuccessMsg(`Chào mừng bạn quay trở lại, ${existing.fullName}!`);
      setTimeout(() => {
        onLoginSuccess(existing, false);
      }, 800);
    } else {
      // If it's a new username and user is just submitting login, suggest registration or auto-create with streak 0
      setErrorMsg("Tài khoản chưa tồn tại! Bạn hãy vào phần 'Đăng ký tài khoản mới' ở phía dưới nhé.");
    }
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");
    setSuccessMsg("");

    if (!username.trim() || !fullName.trim() || !email.trim()) {
      setErrorMsg("Để bắt đầu gia nhập hành trình cải thiện sức khỏe, vui lòng điền đủ tất cả thông tin bạn nhé!");
      return;
    }

    const cleanUsername = username.trim().toLowerCase();
    
    if (accounts[cleanUsername]) {
      setErrorMsg("Tên đăng nhập này đã có người khác sở hữu rồi!");
      return;
    }

    const newAcc: AccountCredentials = {
      username: cleanUsername,
      fullName: fullName.trim(),
      email: email.trim(),
      initialStreak: 0 // New users starts at 0 streak!
    };

    const updated = { ...accounts, [cleanUsername]: newAcc };
    saveRegisteredAccounts(updated);
    setAccounts(updated);
    
    setSuccessMsg(`Đăng ký thành công! Streak của bạn bắt đầu ở mốc 0 ngày.`);
    setTimeout(() => {
      onLoginSuccess(newAcc, true);
    }, 1200);
  };

  // Quick switch credentials immediately
  const handleQuickSelect = (acc: AccountCredentials) => {
    setSuccessMsg(`Chuyển sang tài khoản ${acc.fullName}...`);
    setTimeout(() => {
      onLoginSuccess(acc, false);
    }, 600);
  };

  return (
    <div className="w-full max-w-lg mx-auto min-h-screen flex flex-col justify-center px-4 py-8 bg-zinc-950 text-zinc-100">
      
      {/* Decorative branding elements */}
      <div className="text-center mb-10 space-y-3">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="inline-flex items-center justify-center mx-auto"
        >
          <AppLogo size={74} className="shadow-violet-500/10 shadow-lg" />
        </motion.div>
        
        <div>
          <h1 className="text-3xl font-black tracking-tight uppercase bg-gradient-to-r from-amber-400 via-orange-500 to-red-500 bg-clip-text text-transparent">
            THE ONLY ONE
          </h1>
          <p className="text-xs font-medium tracking-wider text-zinc-400 uppercase mt-1">
            THAY ĐỔI LỐI SỐNG ĐỂ TRỞ THÀNH PHIÊN BẢN TỐT NHẤT
          </p>
        </div>
      </div>

      {/* Main card box with clean form structure */}
      <div className="bg-zinc-900/50 backdrop-blur-md rounded-3xl p-6 border border-zinc-800 shadow-2xl space-y-6">
        
        {/* Signin / Signup navigation header switches */}
        <div className="flex bg-zinc-950 p-1.5 rounded-2xl border border-zinc-800/60">
          <button
            onClick={() => { setIsRegistering(false); setErrorMsg(""); setSuccessMsg(""); }}
            className={`flex-1 py-2.5 text-xs font-bold rounded-xl transition ${
              !isRegistering ? "bg-zinc-900 text-amber-500 border border-zinc-800" : "text-zinc-500 hover:text-zinc-300"
            }`}
          >
            Đăng Nhập
          </button>
          <button
            onClick={() => { setIsRegistering(true); setErrorMsg(""); setSuccessMsg(""); }}
            className={`flex-1 py-2.5 text-xs font-bold rounded-xl transition ${
              isRegistering ? "bg-zinc-900 text-amber-500 border border-zinc-800" : "text-zinc-500 hover:text-zinc-300"
            }`}
          >
            Đăng Ký Mới
          </button>
        </div>

        {/* Displays alert validations feedback */}
        <AnimatePresence mode="wait">
          {errorMsg && (
            <motion.div
              initial={{ opacity: 0, y: -5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="bg-red-500/10 border border-red-500/30 rounded-2xl p-3.5 text-xs text-red-400 flex items-start gap-2.5"
            >
              <ShieldAlert className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </motion.div>
          )}

          {successMsg && (
            <motion.div
              initial={{ opacity: 0, y: -5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="bg-emerald-500/10 border border-emerald-500/30 rounded-2xl p-3.5 text-xs text-emerald-400 flex items-start gap-2.5"
            >
              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>{successMsg}</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Forms handling */}
        <form onSubmit={isRegistering ? handleRegisterSubmit : handleLoginSubmit} className="space-y-4">
          <div>
            <label className="block text-[11px] font-bold text-zinc-500 uppercase tracking-wider mb-1.5 ml-1">
              Tên đăng nhập (Username)
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-3.5 text-zinc-500">
                <User className="w-4 h-4" />
              </span>
              <input
                type="text"
                placeholder="Ví dụ: trinhtranphuongtuan1234"
                value={username}
                onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ""))}
                className="w-full bg-zinc-950 border border-zinc-800 focus:border-amber-500/60 rounded-2xl py-3 pl-10 pr-4 text-sm font-semibold text-zinc-200 outline-none transition font-mono"
              />
            </div>
          </div>

          {isRegistering && (
            <>
              <motion.div
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <label className="block text-[11px] font-bold text-zinc-500 uppercase tracking-wider mb-1.5 ml-1">
                  Họ và tên
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-3.5 text-zinc-400">
                    <Sparkles className="w-4 h-4" />
                  </span>
                  <input
                    type="text"
                    placeholder="Ví dụ: Phùng Thanh Độ"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-amber-500/60 rounded-2xl py-3 pl-10 pr-4 text-sm font-semibold text-zinc-200 outline-none transition"
                  />
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <label className="block text-[11px] font-bold text-zinc-500 uppercase tracking-wider mb-1.5 ml-1">
                  Địa chỉ Email sinh viên
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-3.5 text-zinc-500">
                    <Mail className="w-4 h-4" />
                  </span>
                  <input
                    type="email"
                    placeholder="Ví dụ: mixi@sv.edu.vn"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-amber-500/60 rounded-2xl py-3 pl-10 pr-4 text-sm font-semibold text-zinc-200 outline-none transition"
                  />
                </div>
                <p className="text-[10px] text-zinc-500 mt-1 ml-1">
                  * Đăng ký tài khoản mới sẽ khởi đầu chuỗi mốc **Streak bằng 0 ngày**.
                </p>
              </motion.div>
            </>
          )}

          <button
            type="submit"
            className="w-full mt-2 py-3 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-zinc-950 font-black rounded-2xl text-sm transition-all shadow-xl shadow-amber-950/20 active:scale-95 flex items-center justify-center gap-1.5"
            id="auth-submit-btn"
          >
            {isRegistering ? (
              <>
                <UserPlus className="w-4 h-4 stroke-[2.5]" />
                Kích Hoạt Tài Khoản (Streak = 0)
              </>
            ) : (
              <>
                <LogIn className="w-4 h-4 stroke-[2.5]" />
                Đăng Nhập Ngay
              </>
            )}
          </button>


        </form>
      </div>

      {/* Account Registry switch section - incredibly useful for testing the 49 vs 0 streak logic! */}
      <div className="mt-8 space-y-4">
        <div className="flex items-center gap-2 px-1">
          <div className="h-[1px] bg-zinc-800 flex-1" />
          <span className="text-[10px] font-bold tracking-widest text-zinc-500 uppercase">Tài khoản lưu trên máy của bạn</span>
          <div className="h-[1px] bg-zinc-800 flex-1" />
        </div>

        <div className="grid grid-cols-1 gap-2.5">
          {(Object.values(accounts) as AccountCredentials[]).map((acc) => {
            return (
              <div
                key={acc.username}
                onClick={() => handleQuickSelect(acc)}
                className="group cursor-pointer bg-zinc-900/20 hover:bg-zinc-900/60 p-4 rounded-2xl border border-zinc-800 hover:border-zinc-700 transition-all flex items-center justify-between"
                id={`quick-account-${acc.username}`}
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-zinc-800 text-zinc-400">
                    <User className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-zinc-200 flex items-center gap-1.5 font-sans">
                      {acc.fullName}
                      <span className="text-[9px] font-mono font-medium text-zinc-500">@{acc.username}</span>
                    </div>
                    <div className="text-[10px] text-zinc-500 font-mono mt-0.5">{acc.email}</div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <div className="text-right mr-1">
                    <span className="inline-flex items-center gap-1 text-xs font-black font-mono text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded-lg border border-amber-500/20">
                      <Flame className="w-3.5 h-3.5 fill-amber-500" />
                      {acc.initialStreak} ngày
                    </span>
                  </div>
                  
                  {/* Delete Button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setAccountToDelete(acc);
                    }}
                    className="p-1.5 rounded-lg text-zinc-500 hover:text-rose-400 hover:bg-rose-500/10 transition-all active:scale-90"
                    title="Xóa tài khoản này"
                    id={`btn-delete-account-${acc.username}`}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>

                  <ArrowRight className="w-3.5 h-3.5 text-zinc-600 group-hover:text-zinc-400 group-hover:translate-x-0.5 transition" />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Account Deletion Confirmation Modal */}
      <AnimatePresence>
        {accountToDelete && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/85 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 w-full max-w-sm text-center shadow-2xl "
              id="modal-account-delete-confirm"
            >
              <div className="w-12 h-12 rounded-full bg-rose-500/10 text-rose-500 flex items-center justify-center mx-auto mb-3">
                <Trash2 className="w-6 h-6 animate-pulse" />
              </div>
              <div className="space-y-1.5 mb-5">
                <h3 className="text-base font-black uppercase text-zinc-100 tracking-tight font-sans">Xóa Tài Khoản?</h3>
                <p className="text-xs text-zinc-400 leading-relaxed font-sans">
                  Bạn có chắc chắn muốn xóa tài khoản <span className="font-mono font-black text-amber-500">@{accountToDelete.username}</span> khỏi thiết bị?
                </p>
                <div className="bg-zinc-950/60 p-2.5 rounded-xl border border-zinc-800 text-left">
                  <div className="text-[11px] text-zinc-400 font-bold">Họ tên: {accountToDelete.fullName}</div>
                  <div className="text-[10px] text-zinc-500 font-mono mt-0.5">Email: {accountToDelete.email}</div>
                </div>
                <p className="text-[10px] text-rose-400 italic">
                  * Hành động này sẽ xóa dữ liệu tích lũy và không thể khôi phục!
                </p>
              </div>
              <div className="flex gap-2.5">
                <button
                  onClick={() => setAccountToDelete(null)}
                  className="flex-1 py-2.5 bg-zinc-800 hover:bg-zinc-700 transition font-bold rounded-xl text-xs text-zinc-300 active:scale-95 uppercase tracking-wider"
                  id="btn-delete-cancel"
                >
                  Hủy Bỏ
                </button>
                <button
                  onClick={() => handleDeleteAccount(accountToDelete.username)}
                  className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 transition font-black rounded-xl text-xs text-white active:scale-95 uppercase tracking-wider"
                  id="btn-delete-confirm"
                >
                  Xác Nhận Xóa
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
