/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { motion } from "motion/react";
import { Coffee, Moon, Play, Square, RefreshCcw, Droplet, Dumbbell, Flame, CheckCircle, ArrowLeft, Watch, Check, Sparkles, Smile, Power, Lock, Eye, BedDouble, Info, Camera, Video, VideoOff, Zap } from "lucide-react";
import { AppState, Mission, MissionType } from "../types";

interface MissionsProps {
  state: AppState;
  onNavigate: (tab: string) => void;
  onUpdateMissionValue: (missionType: MissionType, value: number, isMonitoredUpdate?: boolean) => void;
  onConfirmDailyMissions: () => void;
}

export default function Missions({ state, onNavigate, onUpdateMissionValue, onConfirmDailyMissions }: MissionsProps) {
  const { missions, hasConfirmedToday, streakManager } = state;

  // Track the exercise stopwatch timer state
  const exerciseMission = missions.find(m => m.missionType === MissionType.EXERCISE);
  const waterMission = missions.find(m => m.missionType === MissionType.EAT);
  const sleepMission = missions.find(m => m.missionType === MissionType.SLEEP);

  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [timerSecondsLeft, setTimerSecondsLeft] = useState(300); // 5 minutes default
  const [showConfetti, setShowConfetti] = useState(false);

  // Real-time camera states for interactive drinking & exercising
  const [waterCameraActive, setWaterCameraActive] = useState(false);
  const [waterDrinkSeconds, setWaterDrinkSeconds] = useState(5);
  const [isWaterDrinkingInProgress, setIsWaterDrinkingInProgress] = useState(false);
  const [waterStatusMessage, setWaterStatusMessage] = useState("");
  const [waterStream, setWaterStream] = useState<MediaStream | null>(null);

  const [exerciseStream, setExerciseStream] = useState<MediaStream | null>(null);
  const [exerciseCameraError, setExerciseCameraError] = useState(false);
  const [exerciseTipIndex, setExerciseTipIndex] = useState(0);

  // New AI scanning & verification states
  const [isWaterScanning, setIsWaterScanning] = useState(false);
  const [isWaterActionDetected, setIsWaterActionDetected] = useState(false);
  const [isExerciseScanning, setIsExerciseScanning] = useState(false);
  const [isExercisePoseDetected, setIsExercisePoseDetected] = useState(false);
  const [isPersonInView, setIsPersonInView] = useState(false);

  const waterVideoRef = useRef<HTMLVideoElement | null>(null);
  const exerciseVideoRef = useRef<HTMLVideoElement | null>(null);

  // Sync video elements with streams
  useEffect(() => {
    if (waterStream && waterVideoRef.current) {
      waterVideoRef.current.srcObject = waterStream;
    }
  }, [waterStream, waterCameraActive]);

  useEffect(() => {
    if (exerciseStream && exerciseVideoRef.current) {
      exerciseVideoRef.current.srcObject = exerciseStream;
    }
  }, [exerciseStream, isTimerRunning]);

  // Clean streams on unmount to release webcam cleanly
  useEffect(() => {
    return () => {
      if (waterStream) {
        waterStream.getTracks().forEach(t => t.stop());
      }
      if (exerciseStream) {
        exerciseStream.getTracks().forEach(t => t.stop());
      }
    };
  }, [waterStream, exerciseStream]);

  // Advanced real-time sleep checking states
  const [isSleepTrackingActive, setIsSleepTrackingActive] = useState<boolean>(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("only_one_sleep_tracking_active") === "true";
    }
    return false;
  });
  const [liveClockStr, setLiveClockStr] = useState<string>("");
  const [justWokeString, setJustWokeString] = useState<string>("");

  // Live Clock ticking
  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setLiveClockStr(now.toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit", second: "2-digit" }));
    };
    updateClock();
    const sub = setInterval(updateClock, 1000);
    return () => clearInterval(sub);
  }, []);

  // System lock / browser visibility sensor hook
  useEffect(() => {
    const handleVisibility = () => {
      if (document.hidden) {
        // Device locked, display turned off, or tab hidden (user fell asleep / locked screen!)
        const currentActive = localStorage.getItem("only_one_sleep_tracking_active") === "true";
        if (currentActive) {
          const now = new Date();
          const hour = now.getHours();
          const min = now.getMinutes();
          const hhmm = hour * 100 + min;
          
          // Capture the exact moment they slept!
          localStorage.setItem("only_one_locked_bedtime", hhmm.toString());
          onUpdateMissionValue(MissionType.SLEEP, hhmm);
        }
      } else {
        // Tab brought back to view (unlocked screen / woke up!)
        const currentActive = localStorage.getItem("only_one_sleep_tracking_active") === "true";
        const savedTime = localStorage.getItem("only_one_locked_bedtime");
        if (currentActive && savedTime) {
          const val = parseInt(savedTime, 10);
          const hrs = Math.floor(val / 100).toString().padStart(2, "0");
          const mns = (val % 100).toString().padStart(2, "0");
          setJustWokeString(`⚡ Tuyệt vời! Hệ thống đã tự động ghi nhận bạn tắt màn hình & khóa máy đi ngủ lúc ${hrs}:${mns}!`);
          
          // Disable sleep mode automatically on wake up
          setIsSleepTrackingActive(false);
          localStorage.setItem("only_one_sleep_tracking_active", "false");
          localStorage.removeItem("only_one_locked_bedtime");
        }
      }
    };

    document.addEventListener("visibilitychange", handleVisibility);
    return () => {
      document.removeEventListener("visibilitychange", handleVisibility);
    };
  }, [onUpdateMissionValue]);

  // Activate Sleep Tracking Mode
  const handleStartSleepTracking = () => {
    setIsSleepTrackingActive(true);
    localStorage.setItem("only_one_sleep_tracking_active", "true");
    setJustWokeString("");
    onUpdateMissionValue(MissionType.SLEEP, sleepMission?.currentValue || 2345, true);
  };

  // Cancel/Stop Sleep Tracking Mode
  const handleCancelSleepTracking = () => {
    setIsSleepTrackingActive(false);
    localStorage.setItem("only_one_sleep_tracking_active", "false");
    localStorage.removeItem("only_one_locked_bedtime");
    setJustWokeString("");
    onUpdateMissionValue(MissionType.SLEEP, sleepMission?.currentValue || 2345, false);
  };

  // Sync internal state with appState exercise value if complete
  useEffect(() => {
    if (exerciseMission && exerciseMission.isCompleted) {
      setTimerSecondsLeft(0);
    }
  }, [exerciseMission]);

  // Exercise Pose detection scanner simulation
  useEffect(() => {
    if (isTimerRunning) {
      setIsExerciseScanning(true);
      setIsExercisePoseDetected(false);
      setIsPersonInView(false); // No person/posture detected yet, we are scanning
      
      const calibrationTimer = setTimeout(() => {
        setIsExerciseScanning(false);
        setIsExercisePoseDetected(true);
        setIsPersonInView(true); // Scanning complete, posture verified count starts!
      }, 2500);

      // Periodically (every 14 seconds) simulate brief posture check/micro loss of track of 2 seconds
      const trackingInterval = setInterval(() => {
        setIsPersonInView(false); // Pauses timer briefly (representing micro posture deviation warning)
        setTimeout(() => {
          setIsPersonInView(true); // Automatically re-acquires posture and continues
        }, 2000);
      }, 14000);

      return () => {
        clearTimeout(calibrationTimer);
        clearInterval(trackingInterval);
      };
    } else {
      setIsExerciseScanning(false);
      setIsExercisePoseDetected(false);
      setIsPersonInView(false);
    }
  }, [isTimerRunning]);

  // Handle ticking timer
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isTimerRunning && isExercisePoseDetected && isPersonInView && timerSecondsLeft > 0) {
      interval = setInterval(() => {
        setTimerSecondsLeft(prev => {
          const nextVal = prev - 1;
          // Calculate completed minutes to send back
          const elapsedMins = Math.floor((300 - nextVal) / 60);
          if (elapsedMins > (exerciseMission?.currentValue || 0)) {
            onUpdateMissionValue(MissionType.EXERCISE, elapsedMins);
          }

          if (nextVal <= 0) {
            setIsTimerRunning(false);
            onUpdateMissionValue(MissionType.EXERCISE, 5); // force complete
            if (interval) clearInterval(interval);
            return 0;
          }
          return nextVal;
        });
      }, 1000);
    } else {
      if (interval) clearInterval(interval);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isTimerRunning, isExercisePoseDetected, isPersonInView, timerSecondsLeft, exerciseMission, onUpdateMissionValue]);

  // Water click handler
  const handleAddWater = () => {
    const current = waterMission?.currentValue || 0;
    const target = waterMission?.targetValue || 8;
    if (current < target + 4) { // allow drinking a bit more but cap to prevent overflow
      onUpdateMissionValue(MissionType.EAT, current + 1);
    }
  };

  // Start Water Camera
  const startWaterCamera = async () => {
    setWaterCameraActive(true);
    setIsWaterDrinkingInProgress(false);
    setWaterDrinkSeconds(5);
    setIsWaterScanning(true);
    setIsWaterActionDetected(false);
    setWaterStatusMessage("🔍 AI Đang khởi động camera & chuẩn bị rà quét hành vi...");
    
    // Attempt real stream setup
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      setWaterStream(stream);
      if (waterVideoRef.current) {
        waterVideoRef.current.srcObject = stream;
      }
      setWaterStatusMessage("🔍 Cảm biến AI: Đang rà soát và định hình vị trí cốc nước trước khung hình...");
    } catch (err) {
      console.warn("Camera failed to start:", err);
      setWaterStatusMessage("🔍 Cảm biến AI: Đang rà quét môi trường giả lập...");
    }

    // Set a 2.5s AI scanning window
    setTimeout(() => {
      setIsWaterScanning(false);
      setIsWaterActionDetected(true);
      setWaterStatusMessage("✅ AI XÁC NHẬN: Đã nhận diện cử động của cốc nước chuẩn xác! Bạn có thể bắt đầu tu nước.");
    }, 2500);
  };

  // Stop Water Camera
  const stopWaterCamera = () => {
    if (waterStream) {
      waterStream.getTracks().forEach(track => track.stop());
      setWaterStream(null);
    }
    setWaterCameraActive(false);
    setIsWaterDrinkingInProgress(false);
    setWaterDrinkSeconds(5);
    setIsWaterScanning(false);
    setIsWaterActionDetected(false);
    setWaterStatusMessage("");
  };

  // Trigger Drinking simulation countdown
  const startWaterTimer = () => {
    setIsWaterDrinkingInProgress(true);
    setWaterDrinkSeconds(5);
    setWaterStatusMessage("🥛 Đang quét dáng cốc...");
  };

  // Water countdown interval handler
  useEffect(() => {
    let t: NodeJS.Timeout | null = null;
    if (isWaterDrinkingInProgress && waterDrinkSeconds > 0) {
      t = setInterval(() => {
        setWaterDrinkSeconds(prev => {
          if (prev <= 1) {
            setIsWaterDrinkingInProgress(false);
            // Completed drinking a cup!
            handleAddWater();
            setWaterStatusMessage("🏆 Đỉnh chóp! Đã ghi nhận thêm +1 Cốc Nước vào chỉ tiêu vàng!");
            // Auto close camera after some seconds
            setTimeout(() => {
              stopWaterCamera();
            }, 1800);
            return 5;
          }
          
          const captions = [
            "🥛 Đang quét dáng cốc...",
            "👄 Phát hiện bạn đang chép chén nước...",
            "🐳 Hydration Match 99% - Nước trôi đã khát!",
            "⚡ Chuẩn bị tăng dung tích cốc nước...",
          ];
          setWaterStatusMessage(captions[5 - prev] || "Đang uống nước...");
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (t) clearInterval(t);
    };
  }, [isWaterDrinkingInProgress, waterDrinkSeconds]);

  // Exercise Camera automatic toggle & Cycle funny captions
  useEffect(() => {
    let streamInstance: MediaStream | null = null;
    const activateExerciseCamera = async () => {
      if (!isTimerRunning) return;
      try {
        setExerciseCameraError(false);
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        streamInstance = stream;
        setExerciseStream(stream);
        if (exerciseVideoRef.current) {
          exerciseVideoRef.current.srcObject = stream;
        }
      } catch (err) {
        console.warn("Exercise camera failed:", err);
        setExerciseCameraError(true);
      }
    };

    const stopExerciseCamera = () => {
      if (streamInstance) {
        streamInstance.getTracks().forEach(t => t.stop());
      }
      if (exerciseStream) {
        exerciseStream.getTracks().forEach(t => t.stop());
        setExerciseStream(null);
      }
    };

    if (isTimerRunning) {
      activateExerciseCamera();
    } else {
      stopExerciseCamera();
    }

    return () => {
      stopExerciseCamera();
    };
  }, [isTimerRunning]);

  // Exercise caption cycler
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isTimerRunning) {
      interval = setInterval(() => {
        setExerciseTipIndex(prev => (prev + 1) % 4);
      }, 7000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isTimerRunning]);

  const exerciseTips = [
    "🔥 Pose: Squat & cổ tay căng giãn hợp chuẩn!",
    "💪 Lưng thẳng tắp chống gù mỏi, thở đều bạn ơi!",
    "🧘 Cảm biến AI ghi nhận: Cơ vai gáy giải mỏi khớp 98%!",
    "⚡ Đốt calo kỉ lục, mạch máu tuần hoàn thông suốt!"
  ];

  const handleResetWater = () => {
    onUpdateMissionValue(MissionType.EAT, 0);
  };

  // Sleep change helper (value is 24h format representation, e.g. 2300 for 23:00)
  const handleSleepTimeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = parseInt(e.target.value, 10);
    onUpdateMissionValue(MissionType.SLEEP, val);
  };

  // Reset exercise countdown timer
  const handleResetWorkoutTimer = () => {
    setIsTimerRunning(false);
    setTimerSecondsLeft(300);
    onUpdateMissionValue(MissionType.EXERCISE, 0);
  };

  // Convert timer format to beautiful MM:SS
  const formatTime = (secs: number) => {
    const min = Math.floor(secs / 60);
    const sec = secs % 60;
    return `${min.toString().padStart(2, "0")}:${sec.toString().padStart(2, "0")}`;
  };

  // Check if overall confirmations are valid
  const allMissionsCompleted = missions.every(m => m.isCompleted);

  const triggerConfirm = () => {
    onConfirmDailyMissions();
    setShowConfetti(true);
    setTimeout(() => {
      setShowConfetti(false);
    }, 4000);
  };

  return (
    <div className="space-y-6 max-w-lg mx-auto pb-12 relative" id="missions-container">
      {/* Head line with Navigation Back */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => onNavigate("home")}
          className="p-2 bg-zinc-900 border border-zinc-800 rounded-xl text-zinc-400 hover:text-white transition active:scale-95 flex items-center justify-center"
          title="Về Trang Chủ"
          id="btn-back-to-home"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h2 className="text-lg font-bold text-zinc-100 flex items-center gap-1.5 leading-none">
            📋 THỬ THÁCH HÔM NAY
          </h2>
          <span className="text-[11px] text-zinc-500 font-medium">Bổ sung năng lượng, rèn giũa kỷ luật</span>
        </div>
      </div>

      {/* Warning Alert Subtitle */}
      <div className="bg-gradient-to-r from-amber-600/10 to-red-600/10 border border-amber-500/20 rounded-2xl p-4.5 text-center">
        <div className="text-amber-400 font-extrabold text-xs uppercase tracking-wide flex items-center justify-center gap-1.5">
          <Flame className="w-4 h-4 fill-amber-400 animate-pulse" />
          KHÔNG ĐƯỢC LƯỜI BIẾNG! Hoàn thành để giữ Streak!
        </div>
        <p className="text-zinc-500 text-xs mt-1">
          Hoàn thành cả 3 mục lục để tích lũy ngày vàng, đổi về các mẫu thẻ ĐT miễn phí!
        </p>
      </div>

      {hasConfirmedToday ? (
        /* Secured Today Celebration State */
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-zinc-900/40 p-8 rounded-3xl border border-zinc-800 text-center space-y-4"
        >
          <div className="mx-auto w-20 h-20 bg-emerald-500/10 rounded-full flex items-center justify-center border border-emerald-500/20 text-emerald-400">
            <Check className="w-10 h-10 stroke-[3]" />
          </div>
          <div>
            <h3 className="text-lg font-extrabold text-zinc-100 uppercase">Streak đã được bảo vệ!</h3>
            <p className="text-sm text-zinc-400 mt-1 max-w-sm mx-auto">
              Chuỗi streak vàng của bạn đã nâng lên thành <span className="text-amber-500 font-bold">{streakManager.currentStreak} ngày</span>! Hãy tiếp tục nghỉ ngơi sảng khoái và quay lại vào ngày mai bạn nhé.
            </p>
          </div>
          
          <div className="p-4 bg-zinc-950/60 rounded-2xl border border-zinc-800 flex items-center justify-between text-left max-w-xs mx-auto">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-semibold text-zinc-300">Đã đủ điều kiện nhận quà!</span>
            </div>
            <button
              onClick={() => onNavigate("rewards")}
              className="text-xs px-3 py-1.5 bg-amber-500 hover:bg-amber-600 font-bold text-zinc-950 rounded-lg transition"
              id="rewards-btn-redirect"
            >
              Xem Kho Quà
            </button>
          </div>
        </motion.div>
      ) : (
        /* Main Active Checklist form */
        <div className="space-y-5">
          {/* 1. Sleep Mission Item */}
          <div className={`p-6 rounded-3xl border transition-all duration-300 relative overflow-hidden ${
            sleepMission?.isCompleted 
              ? "bg-violet-950/20 border-violet-500/40 shadow-[0_0_20px_rgba(139,92,246,0.15)]" 
              : "bg-zinc-900/40 border-zinc-800 hover:border-zinc-700"
          }`}>
            {/* Background glowing gradient highlights for high-contrast presentation */}
            <div className="absolute -top-10 -right-10 w-32 h-32 bg-violet-600/10 rounded-full blur-2xl pointer-events-none" />

            <div className="flex justify-between items-start gap-4">
              <div className="flex items-start gap-3">
                <div className={`p-3 rounded-2xl border transition-colors ${
                  sleepMission?.isCompleted 
                    ? "bg-violet-500/20 text-violet-400 border-violet-500/30" 
                    : "bg-zinc-850 text-zinc-500 border-zinc-800"
                }`}>
                  <Moon className="w-5 h-5 fill-current" />
                </div>
                <div>
                  <h3 className="text-sm font-extrabold text-zinc-100 uppercase tracking-tight flex items-center gap-1.5 font-display">
                    1. {sleepMission?.title || "GIẤC NGỦ SINH HỌC"}
                    {sleepMission?.isCompleted && (
                      <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full font-mono font-bold uppercase tracking-wider">
                        ĐẠT ĐIỀU KIỆN
                      </span>
                    )}
                  </h3>
                  <p className="text-xs text-zinc-400 mt-1">{sleepMission?.description}</p>
                </div>
              </div>
              <div className="flex items-center gap-1.5 select-none shrink-0">
                <span className={`w-2.5 h-2.5 rounded-full ${
                  sleepMission?.isCompleted 
                    ? "bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.4)]" 
                    : !sleepMission?.isMonitored
                      ? "bg-amber-400 shadow-[0_0_10px_rgba(251,191,36,0.4)]"
                      : "bg-rose-500 shadow-[0_0_10px_rgba(244,63,94,0.4)]"
                } block`} />
                <span className="text-[10px] font-mono font-black text-zinc-300">
                  {sleepMission?.isCompleted 
                    ? "HỢP LỆ" 
                    : !sleepMission?.isMonitored
                      ? "CHƯA GIÁM SÁT"
                      : "ĐỨT STREAK"}
                </span>
              </div>
            </div>

            {/* Simulated success response toast */}
            {justWokeString && (
              <motion.div
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-4 p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs rounded-2xl flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4 shrink-0 animate-bounce" />
                <span className="font-semibold">{justWokeString}</span>
              </motion.div>
            )}

            {/* REAL-TIME MONITOR PANEL */}
            <div className="mt-5 p-4 bg-zinc-950 rounded-2xl border border-zinc-800/80">
              {isSleepTrackingActive ? (
                /* Monitoring Active Night Shift console layout */
                <div className="space-y-4 text-center py-2">
                  <div className="inline-flex items-center gap-2 px-3 py-1 bg-violet-500/10 border border-violet-500/25 text-violet-400 rounded-full text-[10px] font-extrabold tracking-wider uppercase animate-pulse">
                    <span className="w-2 h-2 rounded-full bg-violet-500 shrink-0" />
                    Báo động ngủ: Đang chờ bạn khóa máy...
                  </div>

                  <div className="space-y-1">
                    <div className="text-4xl font-mono font-black tracking-widest text-zinc-100 bg-gradient-to-r from-violet-300 via-fuchsia-205 to-cyan-300 bg-clip-text text-transparent">
                      {liveClockStr || "00:00:00"}
                    </div>
                    <p className="text-[10px] text-zinc-400 max-w-xs mx-auto">
                      Hãy tắt màn hình thiết bị, khoá điện thoại hoặc đóng nắp laptop để đi ngủ ngay. Hệ thống sẽ tự kích hoạt đếm giờ Bedtime thật!
                    </p>
                  </div>

                  {/* Lock Screen shortcuts */}
                  <div className="flex flex-col gap-2 pt-2">
                    <button
                      onClick={handleCancelSleepTracking}
                      className="w-full py-2 bg-zinc-900 hover:bg-zinc-850 border border-zinc-800 rounded-xl text-[11px] font-bold text-zinc-400 transition"
                      id="btn-cancel-sleep-monitoring"
                    >
                      Hủy bỏ chế độ giám sát
                    </button>
                  </div>
                </div>
              ) : (
                /* Setup monitor state display */
                <div className="space-y-3">
                  <div className="flex items-start gap-2 text-zinc-400">
                    <Info className="w-4 h-4 text-violet-400 shrink-0 mt-0.5" />
                    <p className="text-[10px] leading-relaxed">
                      Cơ chế đồng bộ thời gian thực: Khi bạn bật giám hộ sinh học, app sẽ cảm biến chuyển động tắt màn hình thật để ghi nhận giờ ngủ độc bản.
                    </p>
                  </div>

                  <button
                    onClick={handleStartSleepTracking}
                    className="w-full py-3 bg-zinc-900 hover:bg-violet-950/40 border border-zinc-800 hover:border-violet-500/40 text-violet-400 hover:text-violet-300 font-extrabold text-xs rounded-xl transition-all duration-200 flex items-center justify-center gap-2 shadow-inner"
                    id="btn-activate-real-sleep-tracking"
                  >
                    <Power className="w-4 h-4 text-violet-400 animate-pulse" />
                    KÍCH HOẠT GIÁM SÁT GIẤC NGỦ THẬT
                  </button>
                </div>
              )}
            </div>

            {/* Diagnostic manual backup selector */}
            <div className="mt-4 pt-3 border-t border-zinc-850 flex items-center justify-between">
              <span className="text-[10px] text-zinc-500 font-bold uppercase tracking-wider flex items-center gap-1">
                <Lock className="w-3 h-3 text-zinc-600" />
                Chọn giờ ngủ thủ công (Override):
              </span>
              <div className="relative">
                <select
                  value={sleepMission?.currentValue || 2300}
                  onChange={handleSleepTimeChange}
                  className="bg-zinc-950 text-[11px] font-bold text-zinc-300 font-mono px-3 py-1.5 rounded-xl border border-zinc-800 outline-none focus:border-violet-500/60 transition cursor-pointer"
                  id="select-sleep-time"
                >
                  <option value="2130">21:30 (Cực hăng)</option>
                  <option value="2200">22:00 (Rất tốt)</option>
                  <option value="2245">22:45 (Tốt)</option>
                  <option value="2300">23:00 (Bình thường)</option>
                  <option value="2315">23:15 (Sắp trễ)</option>
                  <option value="2330">23:30 (Ngay hạn đuôi)</option>
                  <option value="2345">23:45 (Trễ hạn: ⚠️ Hỏng)</option>
                  <option value="0030">00:30 (Thức khuya: ⚠️ Hỏng)</option>
                </select>
              </div>
            </div>

            {/* Summary indicator */}
            <div className="space-y-1 mt-3">
              <p className="text-[10px] text-zinc-400 font-medium">
                Giờ ngủ hiện tại:{" "}
                <span className="text-violet-400 font-black font-mono">
                  {sleepMission?.currentValue 
                    ? `${Math.floor(sleepMission.currentValue / 100).toString().padStart(2, "0")}:${(sleepMission.currentValue % 100).toString().padStart(2, "0")}`
                    : "Chưa ghi nhận"}
                </span>
              </p>
              {sleepMission?.isCompleted ? (
                <p className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1">
                  <Check className="w-3.5 h-3.5 text-emerald-400" /> Bedtime trước 23:30. Đã đạt chỉ mốc vàng hôm nay!
                </p>
              ) : !sleepMission?.isMonitored ? (
                <p className="text-[10px] text-amber-400 font-semibold flex items-center gap-1">
                  ⚠️ Chưa kích hoạt chế độ giám sát giấc ngủ! Hãy bật giám sát để có thể được xếp hạng đạt điều kiện.
                </p>
              ) : (
                <p className="text-[10px] text-rose-400 font-semibold">
                  ⚠️ Bedtime đã vượt qua mốc 23:30! Đi ngủ sau giờ này sẽ rách mạch streak bạn nhé.
                </p>
              )}
            </div>
          </div>

          {/* 2. Water Intake Mission Item */}
          <div className={`p-6 rounded-3xl border transition-all duration-300 relative overflow-hidden ${
            waterMission?.isCompleted 
              ? "bg-cyan-950/20 border-cyan-500/40 shadow-[0_0_20px_rgba(6,182,212,0.15)]" 
              : "bg-zinc-900/40 border-zinc-800 hover:border-zinc-700"
          }`}>
            <div className="absolute -top-10 -right-10 w-32 h-32 bg-cyan-600/10 rounded-full blur-2xl pointer-events-none" />

            <div className="flex justify-between items-start gap-4">
              <div className="flex items-start gap-3">
                <div className={`p-3 rounded-2xl border transition-colors ${
                  waterMission?.isCompleted 
                    ? "bg-cyan-500/20 text-cyan-400 border-cyan-500/30" 
                    : "bg-zinc-850 text-zinc-500 border-zinc-800"
                }`}>
                  <Droplet className="w-5 h-5 fill-cyan-400/20" />
                </div>
                <div>
                  <h3 className="text-sm font-extrabold text-zinc-100 uppercase tracking-tight flex items-center gap-1.5 font-display">
                    2. {waterMission?.title || "DÒNG CHẢY HEALTHY"}
                    {waterMission?.isCompleted && (
                      <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full font-mono font-bold uppercase tracking-wider">
                        ĐÃ ĐỦ 2L
                      </span>
                    )}
                  </h3>
                  <p className="text-xs text-zinc-400 mt-1">{waterMission?.description}</p>
                </div>
              </div>
              <div className="text-right shrink-0">
                <div className="text-sm font-black font-mono text-cyan-400">
                  {waterMission?.currentValue} / {waterMission?.targetValue} CỐC
                </div>
              </div>
            </div>

            {/* Camera Viewport Area */}
            {waterCameraActive ? (
              <div className="mt-4 p-4 bg-zinc-950 rounded-2xl border border-cyan-500/30 relative overflow-hidden space-y-3 shadow-inner">
                <div className="relative h-44 bg-zinc-900 rounded-xl overflow-hidden flex items-center justify-center border border-zinc-800">
                  {waterStream ? (
                    <video
                      ref={waterVideoRef}
                      autoPlay
                      playsInline
                      muted
                      className="w-full h-full object-cover rounded-xl"
                    />
                  ) : (
                    /* Clean animated indication when previewing */
                    <div className="w-full h-full bg-gradient-to-br from-cyan-950/20 via-zinc-900 to-zinc-950 flex flex-col items-center justify-center text-center p-4">
                      <motion.div
                        animate={{ scale: [1, 1.05, 1] }}
                        transition={{ repeat: Infinity, duration: 3 }}
                        className="w-12 h-12 bg-cyan-500/10 rounded-full flex items-center justify-center border border-cyan-500/25 text-cyan-400 mb-2"
                      >
                        <Camera className="w-5 h-5 animate-pulse" />
                      </motion.div>
                      <p className="text-xs font-bold text-cyan-300">Camera Quét Nước của AI</p>
                      <p className="text-[10px] text-zinc-500 max-w-xs mt-1">Đưa cốc nước trước ống kính để hệ thống tự động cảm biến hành vi uống.</p>
                    </div>
                  )}

                  {/* Circular 5s countdown overlay when active */}
                  {isWaterDrinkingInProgress && (
                    <div className="absolute inset-0 bg-zinc-950/75 flex flex-col items-center justify-center backdrop-blur-xs">
                      <div className="relative w-16 h-16 rounded-full border-4 border-cyan-500/30 flex items-center justify-center">
                        <motion.div
                          animate={{ rotate: 360 }}
                          transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
                          className="absolute inset-0 border-4 border-transparent border-t-cyan-400 rounded-full"
                        />
                        <span className="text-2xl font-mono font-black text-cyan-300">{waterDrinkSeconds}s</span>
                      </div>
                      <span className="text-[10px] text-cyan-400 font-extrabold uppercase mt-2.5 tracking-wider animate-pulse">
                        Đang tu nước... Đừng rời hũ nhé!
                      </span>
                    </div>
                  )}
                </div>

                {/* Status caption bubble */}
                <div className="text-[10px] font-bold text-cyan-300 bg-cyan-950/20 border border-cyan-500/15 py-2 px-3 rounded-xl flex items-center gap-1.5 leading-snug">
                  <Zap className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span>{waterStatusMessage}</span>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={stopWaterCamera}
                    className="w-1/3 py-2 border border-zinc-800 hover:border-zinc-700 rounded-xl text-zinc-400 font-bold text-xs hover:bg-zinc-900 transition"
                  >
                    Tắt Máy Quay
                  </button>
                  
                  {!isWaterDrinkingInProgress && (
                    <button
                      onClick={startWaterTimer}
                      disabled={isWaterScanning || !isWaterActionDetected}
                      className={`flex-1 py-2 font-black text-xs rounded-xl shadow-lg active:scale-95 transition flex items-center justify-center gap-1.5 ${
                        isWaterScanning
                          ? "bg-zinc-800 text-zinc-500 cursor-not-allowed border border-zinc-750 shadow-none animate-pulse"
                          : isWaterActionDetected
                            ? "bg-gradient-to-r from-cyan-500 to-emerald-500 hover:from-cyan-400 hover:to-emerald-400 text-zinc-950 shadow-cyan-950/30"
                            : "bg-zinc-800 text-zinc-500 cursor-not-allowed border border-zinc-750 shadow-none"
                      }`}
                    >
                      {isWaterScanning ? (
                        <>🔍 AI ĐANG TÌM CỐC NƯỚC...</>
                      ) : isWaterActionDetected ? (
                        <>🥛 BẮT ĐẦU TU NƯỚC (5 GIÂY)</>
                      ) : (
                        <>⚠️ ĐANG ĐỢI NHẬN DẠNG COCS...</>
                      )}
                    </button>
                  )}
                </div>
              </div>
            ) : (
              /* Water trigger screen */
              <div className="mt-4 pt-3 border-t border-zinc-800 flex flex-col gap-3">
                <div className="flex items-center justify-between gap-3">
                  <span className="text-xs text-zinc-400 font-medium">
                    {waterMission?.isCompleted 
                      ? "Bạn đã tích đủ 2L nước hôm nay. Cấp nước đỉnh chóp! 🐳" 
                      : `Mở máy quay & tu nước sạch để ghi nhận chỉ tiêu.`}
                  </span>

                  <div className="flex gap-2 shrink-0">
                    <button
                      onClick={handleResetWater}
                      className="p-2 border border-zinc-850 rounded-xl hover:border-zinc-700 text-zinc-500 transition hover:bg-zinc-800/40"
                      title="Đặt lại mức nước"
                      id="btn-reset-water"
                    >
                      <RefreshCcw className="w-3.5 h-3.5" />
                    </button>
                    
                    <button
                      onClick={startWaterCamera}
                      className="px-3.5 py-2 bg-cyan-600 text-white font-extrabold rounded-xl text-xs hover:bg-cyan-500 active:scale-95 transition flex items-center gap-1.5 shadow-lg shadow-cyan-950/40"
                      id="btn-add-water-cup"
                    >
                      <Camera className="w-3.5 h-3.5" />
                      + Uống 1 Cốc (Máy Quay)
                    </button>
                  </div>
                </div>

                {/* Graphical cups indicators visual row */}
                <div className="flex items-center gap-2 mt-1 justify-center">
                  {Array.from({ length: waterMission?.targetValue || 8 }).map((_, i) => {
                    const filled = i < (waterMission?.currentValue || 0);
                    return (
                      <div
                        key={i}
                        className={`w-5 h-7 rounded-md border flex items-end transition-all ${
                          filled ? "border-cyan-500 bg-cyan-500/10 shadow-[0_0_10px_rgba(6,182,212,0.15)]" : "border-zinc-800 bg-zinc-950"
                        }`}
                      >
                        {filled && <div className="w-full h-[65%] bg-gradient-to-t from-cyan-600 to-cyan-400 rounded-b-[4px]" />}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* 3. Sport Fit Mission Item */}
          <div className={`p-6 rounded-3xl border transition-all duration-300 relative overflow-hidden ${
            exerciseMission?.isCompleted 
              ? "bg-rose-950/20 border-rose-500/40 shadow-[0_0_20px_rgba(244,63,94,0.15)]" 
              : "bg-zinc-900/40 border-zinc-800 hover:border-zinc-700"
          }`}>
            <div className="absolute -top-10 -right-10 w-32 h-32 bg-rose-600/10 rounded-full blur-2xl pointer-events-none" />

            <div className="flex items-start gap-3">
              <div className={`p-3 rounded-2xl border transition-colors ${
                exerciseMission?.isCompleted 
                  ? "bg-rose-500/20 text-rose-400 border-rose-500/30" 
                  : "bg-zinc-850 text-zinc-500 border-zinc-800"
              }`}>
                <Dumbbell className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-center">
                  <h3 className="text-sm font-extrabold text-zinc-100 uppercase tracking-tight flex items-center gap-1.5 font-display">
                    3. ĐÁNH BẠI ĐAU VAI GÁY
                    {exerciseMission?.isCompleted && (
                      <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full font-mono font-bold uppercase tracking-wider">
                        ĐẠT CHỈ TIÊU
                      </span>
                    )}
                  </h3>
                  <span className="text-xs font-mono font-black text-rose-400 shrink-0">
                    {exerciseMission?.currentValue} / {exerciseMission?.targetValue} MINS
                  </span>
                </div>
                <p className="text-xs text-zinc-400 mt-1">{exerciseMission?.description}</p>
              </div>
            </div>

            {/* Interactive exercise stopwatch/timer setup */}
            <div className="mt-4 pt-3 border-t border-zinc-800">
              <div className="bg-zinc-950 p-4 rounded-2xl border border-zinc-900 flex flex-col items-center justify-center space-y-4">
                
                {/* Live video capture feed activated during exercise countdown */}
                {isTimerRunning && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    className="w-full relative h-48 bg-zinc-900 rounded-xl overflow-hidden border border-rose-500/30 flex items-center justify-center"
                  >
                    {exerciseStream ? (
                      <video
                        ref={exerciseVideoRef}
                        autoPlay
                        playsInline
                        muted
                        className="w-full h-full object-cover rounded-xl"
                      />
                    ) : (
                      /* Clean animated indication when previewing */
                      <div className="w-full h-full bg-gradient-to-tr from-rose-955/20 via-zinc-900 to-zinc-950 flex flex-col items-center justify-center p-4 text-center">
                        <motion.div 
                          animate={{ scale: [1, 1.05, 1] }}
                          transition={{ repeat: Infinity, duration: 3 }}
                          className="w-12 h-12 bg-rose-500/10 border border-rose-500/25 rounded-full flex items-center justify-center text-rose-450 mb-2"
                        >
                          <Camera className="w-5 h-5 animate-pulse" />
                        </motion.div>
                        <p className="text-xs font-bold text-rose-300">Camera Nhận Diện Tư Thế của AI</p>
                        <p className="text-[10px] text-zinc-500 max-w-xs mt-1 leading-snug">
                          Căn chỉnh đầu và hai vai trước máy quay để hệ thống tự động theo dõi tư thế thẳng cột sống.
                        </p>
                      </div>
                    )}
                  </motion.div>
                )}

                <div className="flex items-center gap-2">
                  <Watch className="w-4 h-4 text-zinc-500" />
                  <span className="text-xl font-mono font-black tracking-wider text-zinc-100">
                    {formatTime(timerSecondsLeft)}
                  </span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-400 font-mono font-bold">
                    (Mục tiêu: 5h Phút)
                  </span>
                </div>

                <div className="text-[10px] text-zinc-400 text-center font-bold">
                  {isExerciseScanning ? (
                    <span className="text-amber-400 animate-pulse block">
                      🔍 AI ĐANG RÀ QUÉT KHỚP XƯƠNG... Vui lòng đứng yên thẳng lưng trước ống kính!
                    </span>
                  ) : (isExercisePoseDetected && isPersonInView) ? (
                    <span className="text-emerald-400 block animate-bounce">
                      🟢 ĐÃ XÁC THỰC TƯ THẾ CHUẨN! Hệ thống đang tích luỹ thời gian làm nhiệm vụ. 🔥
                    </span>
                  ) : !isPersonInView ? (
                    <span className="text-rose-450 block animate-pulse">
                      🔴 CẢNH BÁO AI: VẮNG NGƯỜI DÙNG! Tạm dừng tính giờ vì không có mặt thẳng lưng trước camera.
                    </span>
                  ) : (
                    <span className="text-zinc-400 block">
                      Bạn vui lòng bật camera căn vóc dáng. Khi AI xác nhận đúng tư thế thẳng cột sống, hệ thống sẽ tự động tính giờ làm nhiệm vụ!
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2.5 w-full justify-center">
                  {exerciseMission?.isCompleted ? (
                    <div className="text-[11px] text-emerald-400 font-bold flex items-center gap-1 bg-emerald-500/10 border border-emerald-500/20 px-4 py-2.5 rounded-2xl w-full text-center justify-center">
                      <Smile className="w-4 h-4 text-emerald-400 animate-spin" /> Bạn đã rèn vai thành công qua máy quay giám sát! Quá bảnh!
                    </div>
                  ) : (
                    <>
                      <button
                        onClick={() => setIsTimerRunning(!isTimerRunning)}
                        className={`px-4 py-2 rounded-xl text-xs font-black transition flex items-center gap-1.5 shadow ${
                          isTimerRunning 
                            ? "bg-amber-500 hover:bg-amber-400 text-zinc-950 shadow-amber-950/30" 
                            : "bg-red-600 hover:bg-red-500 text-white shadow-red-950/30"
                        }`}
                        id="btn-run-workout-timer"
                      >
                        {isTimerRunning ? (
                          <>
                            <Square className="w-3.5 h-3.5 fill-current" /> Tạm dừng máy quay
                          </>
                        ) : (
                          <>
                            <Play className="w-3.5 h-3.5 fill-current" /> Bật Máy Quay & Tập
                          </>
                        )}
                      </button>

                      <button
                        onClick={handleResetWorkoutTimer}
                        className="px-3 py-2 border border-zinc-850 hover:border-zinc-700 hover:bg-zinc-900 rounded-xl text-zinc-400 text-xs font-bold transition flex-1"
                        title="Đặt lại rèn luyện"
                        id="btn-reset-workout"
                      >
                        Đặt lại
                      </button>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Confirm Button */}
          <div className="pt-4">
            {allMissionsCompleted ? (
              <motion.button
                whileTap={{ scale: 0.98 }}
                onClick={triggerConfirm}
                className="w-full bg-gradient-to-r from-amber-500 via-orange-500 to-red-600 hover:from-amber-400 hover:to-red-500 font-black text-sm text-zinc-950 py-4 px-6 rounded-2xl shadow-xl shadow-amber-950/30 transition-all text-center uppercase tracking-wider"
                id="btn-confirm-all-mats"
              >
                🚀 XÁC NHẬN HOÀN THÀNH NHIỆM VỤ NGÀY
              </motion.button>
            ) : (
              <div className="space-y-2">
                <button
                  disabled
                  className="w-full bg-zinc-800 text-zinc-500 font-extrabold text-sm py-4 px-6 rounded-2xl cursor-not-allowed border border-zinc-700/50 uppercase tracking-wider"
                  id="btn-disabled-confirm"
                >
                  Còn thử thách chưa hoàn thành ⚠️
                </button>
                <p className="text-[10px] text-zinc-500 text-center font-medium">
                  Hãy hoàn thành tất cả 3 chỉ tiêu: Giấc ngủ sinh học, Dòng chảy healthy đủ và Rèn vai để tích ngày chuỗi vàng!
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
