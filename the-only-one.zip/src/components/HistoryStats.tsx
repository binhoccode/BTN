/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Flame, Moon, Droplet, Dumbbell, Award, HelpCircle, TrendingUp, Calendar, CheckCircle, BarChart3 } from "lucide-react";
import { AppState, MissionType } from "../types";

interface HistoryStatsProps {
  state: AppState;
}

export default function HistoryStats({ state }: HistoryStatsProps) {
  const { user, streakManager, rewards, missions } = state;

  // Calculate stats values
  const totalClaimedRewardsCount = rewards.filter(r => r.isClaimed).length;
  const totalClaimedValue = rewards
    .filter(r => r.isClaimed)
    .reduce((sum, r) => sum + r.rewardValue, 0);

  const isNewAccount = (state.user?.currentStreak || 0) <= 0;

  const sleepMission = missions.find(m => m.missionType === MissionType.SLEEP);
  const waterMission = missions.find(m => m.missionType === MissionType.EAT);
  const exerciseMission = missions.find(m => m.missionType === MissionType.EXERCISE);

  // Get current day of week in Vietnam/Local time
  const dayIndex = new Date().getDay(); // 0 (Sun) to 6 (Sat)
  const logIndex = dayIndex === 0 ? 6 : dayIndex - 1; // Map Sun to index 6, Mon to 0, etc.

  const currentSleepTimeStr = sleepMission?.currentValue 
    ? `${Math.floor(sleepMission.currentValue / 100).toString().padStart(2, "0")}:${(sleepMission.currentValue % 100).toString().padStart(2, "0")}`
    : "--:--";

  const currentSleepStatus = sleepMission?.currentValue
    ? (sleepMission.isCompleted ? "Tốt" : "Chưa Tốt")
    : "Chưa ghi nhận";

  const baseHydrationLog = isNewAccount 
    ? [
        { day: "Thứ 2", cups: 0, achieved: false },
        { day: "Thứ 3", cups: 0, achieved: false },
        { day: "Thứ 4", cups: 0, achieved: false },
        { day: "Thứ 5", cups: 0, achieved: false },
        { day: "Thứ 6", cups: 0, achieved: false },
        { day: "Thứ 7", cups: 0, achieved: false },
        { day: "Chủ Nhật", cups: 0, achieved: false }
      ]
    : [
        { day: "Thứ 2", cups: 8, achieved: true },
        { day: "Thứ 3", cups: 7, achieved: false },
        { day: "Thứ 4", cups: 9, achieved: true },
        { day: "Thứ 5", cups: 8, achieved: true },
        { day: "Thứ 6", cups: 5, achieved: false },
        { day: "Thứ 7", cups: 8, achieved: true },
        { day: "Chủ Nhật", cups: 10, achieved: true }
      ];

  const baseSleepLog = isNewAccount
    ? [
        { day: "Thứ 2", bedtime: "--:--", status: "Chưa ghi nhận" },
        { day: "Thứ 3", bedtime: "--:--", status: "Chưa ghi nhận" },
        { day: "Thứ 4", bedtime: "--:--", status: "Chưa ghi nhận" },
        { day: "Thứ 5", bedtime: "--:--", status: "Chưa ghi nhận" },
        { day: "Thứ 6", bedtime: "--:--", status: "Chưa ghi nhận" },
        { day: "Thứ 7", bedtime: "--:--", status: "Chưa ghi nhận" },
        { day: "Chủ Nhật", bedtime: "--:--", status: "Chưa ghi nhận" }
      ]
    : [
        { day: "Thứ 2", bedtime: "23:10", status: "Tốt" },
        { day: "Thứ 3", bedtime: "23:00", status: "Tốt" },
        { day: "Thứ 4", bedtime: "23:45", status: "Chưa Tốt" },
        { day: "Thứ 5", bedtime: "22:50", status: "Tốt" },
        { day: "Thứ 6", bedtime: "00:15", status: "Chưa Tốt" },
        { day: "Thứ 7", bedtime: "23:15", status: "Tốt" },
        { day: "Chủ Nhật", bedtime: "22:30", status: "Tốt" }
      ];

  const baseExerciseLog = isNewAccount
    ? [
        { day: "Thứ 2", duration: 0, label: "Chưa Tập" },
        { day: "Thứ 3", duration: 0, label: "Chưa Tập" },
        { day: "Thứ 4", duration: 0, label: "Chưa Tập" },
        { day: "Thứ 5", duration: 0, label: "Chưa Tập" },
        { day: "Thứ 6", duration: 0, label: "Chưa Tập" },
        { day: "Thứ 7", duration: 0, label: "Chưa Tập" },
        { day: "Chủ Nhật", duration: 0, label: "Chưa Tập" }
      ]
    : [
        { day: "Thứ 2", duration: 15, label: "Hăng Say" },
        { day: "Thứ 3", duration: 5, label: "Đủ Mốc" },
        { day: "Thứ 4", duration: 0, label: "Lười Biếng" },
        { day: "Thứ 5", duration: 10, label: "Hăng Say" },
        { day: "Thứ 6", duration: 12, label: "Hăng Say" },
        { day: "Thứ 7", duration: 0, label: "Lười Biếng" },
        { day: "Chủ Nhật", duration: 25, label: "Chiến Thần" }
      ];

  // Overlay today's live stats
  const weeklyHydrationLog = baseHydrationLog.map((item, index) => {
    if (index === logIndex) {
      return {
        ...item,
        cups: waterMission?.currentValue || 0,
        achieved: waterMission?.isCompleted || false
      };
    }
    return item;
  });

  const weeklySleepLog = baseSleepLog.map((item, index) => {
    if (index === logIndex) {
      return {
        ...item,
        bedtime: currentSleepTimeStr,
        status: currentSleepStatus
      };
    }
    return item;
  });

  const weeklyExerciseLog = baseExerciseLog.map((item, index) => {
    if (index === logIndex) {
      return {
        ...item,
        duration: exerciseMission?.currentValue || 0,
        label: exerciseMission?.isCompleted ? "Đủ Mốc" : "Chưa Tập"
      };
    }
    return item;
  });

  return (
    <div className="space-y-6 max-w-lg mx-auto pb-12">
      {/* Page Title */}
      <div>
        <h2 className="text-lg font-bold text-zinc-100 flex items-center gap-1.5 leading-none">
          <BarChart3 className="w-5 h-5 text-amber-500" />
          📊 THỐNG KÊ KỶ LUẬT
        </h2>
        <span className="text-[11px] text-zinc-500 font-medium">Lắng nghe nhịp sống của bạn qua từng dữ liệu</span>
      </div>

      {/* Bento Grid Highlights */}
      <div className="grid grid-cols-2 gap-3.5">
        {/* Record streak log */}
        <div className="bg-zinc-900/30 p-4 rounded-2xl border border-zinc-800 shadow flex flex-col justify-between">
          <div className="flex items-center gap-1.5 text-[10px] text-zinc-500 uppercase tracking-wider font-semibold">
            <Flame className="w-4 h-4 text-amber-500 fill-amber-500/15" />
            KỶ LỤC STREAK
          </div>
          <div className="mt-2 text-2xl font-black text-amber-500 font-mono">
            {Math.max(user.highestStreak, streakManager.currentStreak)} ngày
          </div>
          <div className="mt-1 text-[10px] text-zinc-400">
            Cao gấp đôi trung bình sinh viên cùng khoá!
          </div>
        </div>

        {/* Claimed financial card log */}
        <div className="bg-zinc-900/30 p-4 rounded-2xl border border-zinc-800 shadow flex flex-col justify-between">
          <div className="flex items-center gap-1.5 text-[10px] text-zinc-500 uppercase tracking-wider font-semibold">
            <Award className="w-4 h-4 text-emerald-400" />
            TIỀN TÍCH LŨY ĐƯỢC
          </div>
          <div className="mt-2 text-2xl font-black text-emerald-400 font-mono">
            {totalClaimedValue.toLocaleString()}đ
          </div>
          <div className="mt-1 text-[10px] text-zinc-400">
            Đã nhận về {totalClaimedRewardsCount} thẻ điện thoại.
          </div>
        </div>
      </div>

      {/* 1. Sleep Bedtime Graph Log */}
      <div className="bg-zinc-950/80 p-5 rounded-3xl border border-zinc-800/80 space-y-4">
        <h3 className="text-xs uppercase font-extrabold tracking-widest text-zinc-400 flex items-center gap-1.5">
          <Moon className="w-4 h-4 text-indigo-400" />
          🕒 Nhịp ngủ 7 ngày trước (Bedtimes)
        </h3>

        <div className="space-y-2">
          {weeklySleepLog.map((log, i) => {
            const isGood = log.status === "Tốt";
            return (
              <div key={i} className="flex items-center justify-between text-xs py-1.5 border-b border-zinc-900 last:border-0">
                <span className="text-zinc-400 font-medium">{log.day}</span>
                <div className="flex items-center gap-3">
                  <span className={`font-mono ${isGood ? "text-emerald-400 font-bold" : log.status === "Chưa ghi nhận" ? "text-zinc-600" : "text-rose-450"} font-semibold`}>
                    {log.bedtime}
                  </span>
                  <span className={`text-[10px] px-2 py-0.5 rounded-md font-bold uppercase tracking-tight ${
                    log.status === "Tốt" 
                      ? "bg-emerald-500/15 text-emerald-400 border border-emerald-500/20" 
                      : log.status === "Chưa ghi nhận" 
                        ? "bg-zinc-805 text-zinc-500 border border-zinc-900" 
                        : "bg-rose-500/10 text-rose-450 border border-rose-500/10"
                  }`}>
                    {log.status}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 2. Hydration Cups Visual Meter */}
      <div className="bg-zinc-950/80 p-5 rounded-3xl border border-zinc-800/80 space-y-4">
        <h3 className="text-xs uppercase font-extrabold tracking-widest text-zinc-400 flex items-center gap-1.5">
          <Droplet className="w-4 h-4 text-cyan-400" />
          🐳 Lượng nước nạp vào (Mục tiêu 8 cốc)
        </h3>

        {/* Custom bar chart representation directly in HTML tags for perfect rendering safety */}
        <div className="grid grid-cols-7 gap-2.5 pt-2">
          {weeklyHydrationLog.map((log, i) => {
            const pct = Math.min(100, Math.round((log.cups / 8) * 100));
            return (
              <div key={i} className="flex flex-col items-center space-y-2">
                <div className="w-3.5 h-24 bg-zinc-900 rounded-full flex items-end">
                  <div
                    style={{ height: `${pct}%` }}
                    className={`w-full rounded-full ${
                      log.achieved ? "bg-gradient-to-t from-cyan-600 to-cyan-400 shadow-sm" : "bg-cyan-900/60"
                    }`}
                  />
                </div>
                <span className="text-[10px] font-mono font-bold text-zinc-300 md:text-zinc-400">{log.cups}c</span>
                <span className="text-[9px] text-zinc-500 text-center font-mono">{log.day.split(" ")[1]}</span>
              </div>
            );
          })}
        </div>
        <div className="text-[10px] text-zinc-500 font-medium text-center">
          Tỷ lệ cấp nước đạt chuẩn trung bình trong tuần: <span className="text-cyan-400 font-bold">{isNewAccount ? "Ghi nhận từ hôm nay 🐳" : "71%"}</span>
        </div>
      </div>

      {/* 3. Workout Weekly Log */}
      <div className="bg-zinc-950/80 p-5 rounded-3xl border border-zinc-800/80 space-y-4">
        <h3 className="text-xs uppercase font-extrabold tracking-widest text-zinc-400 flex items-center gap-1.5">
          <Dumbbell className="w-4 h-4 text-red-400" />
          💪 Giãn vai chống mỏi (Phút tập luyện)
        </h3>

        <div className="grid grid-cols-7 gap-2.5 pt-2">
          {weeklyExerciseLog.map((log, i) => {
            const pct = Math.min(100, Math.round((log.duration / 15) * 100));
            return (
              <div key={i} className="flex flex-col items-center space-y-2">
                <div className="w-3.5 h-24 bg-zinc-900 rounded-full flex items-end">
                  <div
                    style={{ height: `${pct}%` }}
                    className={`w-full rounded-full ${
                      log.duration > 0 ? "bg-gradient-to-t from-red-650 to-red-450" : "bg-zinc-950"
                    }`}
                  />
                </div>
                <span className="text-[10px] font-mono font-bold text-zinc-350">{log.duration}m</span>
                <span className="text-[9px] text-zinc-500 text-center font-mono">{log.day.split(" ")[1]}</span>
              </div>
            );
          })}
        </div>
        <div className="text-[10px] text-zinc-500 font-medium text-center">
          Tổng số phút bạn bảo vệ khớp cổ vai trong tuần: <span className="text-red-400 font-bold font-mono">{isNewAccount ? `${exerciseMission?.currentValue || 0} phút (Hôm nay)` : "67 phút"}</span>
        </div>
      </div>
    </div>
  );
}
