/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { motion } from "motion/react";
import { Flame, Ticket, Moon, Droplet, Dumbbell, Sparkles, Settings, ArrowRight, AlertTriangle, CheckCircle, Lightbulb, LogOut, Calendar, Trash2 } from "lucide-react";
import { AppState, MissionType } from "../types";
import AppLogo from "./AppLogo";

interface DashboardProps {
  state: AppState;
  onNavigate: (tab: string) => void;
  onLogout: () => void;
  onDeleteAccount: () => void;
}

export default function Dashboard({ state, onNavigate, onLogout, onDeleteAccount }: DashboardProps) {
  const { user, missions, streakManager } = state;

  const [liveTime, setLiveTime] = React.useState<string>("");
  const [showDeleteConfirm, setShowDeleteConfirm] = React.useState<boolean>(false);

  React.useEffect(() => {
    const tick = () => {
      const now = new Date();
      setLiveTime(now.toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit", second: "2-digit" }));
    };
    tick();
    const timer = setInterval(tick, 1000);
    return () => clearInterval(timer);
  }, []);

  // Calculate percentage of missions finished today
  const sleepMission = missions.find(m => m.missionType === MissionType.SLEEP);
  const waterMission = missions.find(m => m.missionType === MissionType.EAT);
  const exerciseMission = missions.find(m => m.missionType === MissionType.EXERCISE);

  const completedCount = missions.filter(m => m.isCompleted).length;
  const totalMissionsCount = missions.length;
  const completionPercentage = Math.round((completedCount / totalMissionsCount) * 100);

  // Get current streak status text & colors
  const currentStreak = streakManager.currentStreak;
  let prevMilestone = 0;
  let nextMilestone = 50;
  let milestoneReward = "10K";

  if (currentStreak >= 400) {
    prevMilestone = 400;
    nextMilestone = Math.ceil((currentStreak + 1) / 100) * 100;
    milestoneReward = `${200 + Math.round((nextMilestone - 400) * 0.5)}K`;
  } else if (currentStreak >= 300) {
    prevMilestone = 300;
    nextMilestone = 400;
    milestoneReward = "200K";
  } else if (currentStreak >= 200) {
    prevMilestone = 200;
    nextMilestone = 300;
    milestoneReward = "150K";
  } else if (currentStreak >= 100) {
    prevMilestone = 100;
    nextMilestone = 200;
    milestoneReward = "100K";
  } else if (currentStreak >= 50) {
    prevMilestone = 50;
    nextMilestone = 100;
    milestoneReward = "50K";
  } else {
    prevMilestone = 0;
    nextMilestone = 50;
    milestoneReward = "10K";
  }

  const daysRemaining = nextMilestone - currentStreak;
  const milestoneProgress = ((currentStreak - prevMilestone) / (nextMilestone - prevMilestone)) * 100;
  const showPercent = Math.round(milestoneProgress);

  // Format sleep value to readable HH:MM 
  const formatSleepTime = (val: number) => {
    const hours = Math.floor(val / 100);
    const minutes = val % 100;
    return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`;
  };

  return (
    <div className="space-y-6 max-w-lg mx-auto pb-10">
      {/* Header section with Unique Logo and simulation/settings triggers */}
      <div className="flex items-center justify-between bg-zinc-950/80 backdrop-blur-xl p-4 rounded-3xl border border-zinc-850 shadow-xl">
        <div className="flex items-center gap-2.5">
          <AppLogo size={42} className="shadow-violet-500/10 shadow-lg" />
          <div>
            <div className="text-xs font-mono font-black tracking-widest text-violet-400">THE ONLY ONE</div>
            <div className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider">Thay đổi lối sống trở thành phiên bản khỏe mạnh nhất</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onLogout}
            className="p-2.5 rounded-2xl bg-zinc-900/80 text-rose-400 hover:text-rose-500 hover:bg-rose-500/10 transition-all border border-zinc-800 active:scale-95"
            title="Đăng xuất tài khoản"
            id="btn-logout-dashboard"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Breaking Streak Alert Banner */}
      {streakManager.isBroken && user.highestStreak > 0 && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-rose-550/10 border border-rose-500/20 rounded-2xl p-4 flex items-start gap-3 shadow-lg"
        >
          <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <h4 className="text-sm font-semibold text-rose-250">Chuỗi Streak của bạn đang bị đứt! 😭</h4>
            <p className="text-xs text-zinc-400 mt-1">
              Hôm qua bạn chưa tích đủ 3 thử thách vàng hoặc nhỡ quên ấn xác nhận. Dùng ngay vé cứu tinh để hồi sinh mạch vàng nhé!
            </p>
            <button
              onClick={() => onNavigate("rewards")}
              className="mt-2.5 flex items-center gap-1 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 transition px-3 py-1.5 rounded-xl"
              id="btn-nav-revive-from-banner"
            >
              Hồi sinh Streak ngay!
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </motion.div>
      )}

      {/* Greeting Banner */}
      <div className="text-center py-2">
        <h2 className="text-xl font-bold bg-gradient-to-r from-violet-350 via-fuchsia-350 to-cyan-300 bg-clip-text text-transparent">
          Chào bạn {user.userName.split(" ").slice(-1)[0]}!
        </h2>
        <p className="text-xs text-zinc-400 font-bold tracking-normal">
          Hôm nay bạn đã bảo vệ sức khỏe của mình đến đâu rồi?
        </p>
      </div>

      {/* Real-time Date and Time display */}
      <div className="bg-zinc-900/35 border border-zinc-850 rounded-2xl px-4 py-3 flex items-center justify-between text-xs text-zinc-400 shadow-md">
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-violet-400" />
          <span className="font-semibold text-zinc-300">
            {new Date().toLocaleDateString("vi-VN", {
              weekday: "long",
              day: "2-digit",
              month: "2-digit",
              year: "numeric"
            })}
          </span>
        </div>
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-zinc-950 text-[10px] font-mono font-bold text-cyan-400 border border-zinc-900 tracking-wide">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
          TIME: {liveTime || "00:00:00"}
        </div>
      </div>

      {/* Active Streak Monitor Card */}
      <motion.div
        whileHover={{ y: -2 }}
        transition={{ duration: 0.2 }}
        className="relative overflow-hidden bg-gradient-to-br from-zinc-950 via-zinc-900 to-zinc-950 p-6 rounded-3xl border border-violet-500/20 shadow-2xl group transition-all"
      >
        {/* Background glow effects with neon violet / cyan lights */}
        <div className="absolute top-0 right-0 w-36 h-36 bg-violet-500/10 rounded-full blur-3xl pointer-events-none group-hover:bg-violet-500/15 transition-colors" />
        <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none group-hover:bg-cyan-500/15 transition-colors" />

        <div className="flex justify-between items-start">
          <div>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black bg-violet-550/20 text-violet-300 border border-violet-500/30 uppercase tracking-widest mb-3.5">
              <Flame className="w-3" />
              STREAK
            </span>
            <h3 className="text-base font-black text-zinc-100 uppercase tracking-tight font-display">
              🔥 Chuỗi tích lũy vàng
            </h3>
          </div>
          <div className="text-right">
            <span className="text-5xl font-black font-mono tracking-tighter bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent animate-pulse block">
              {streakManager.currentStreak}
            </span>
            <span className="text-[10px] font-black text-zinc-400 uppercase tracking-wider block mt-1">Ngày liên tiếp</span>
          </div>
        </div>

        {/* Milestone Target & Message */}
        <div className="mt-6 space-y-2.5">
          <div className="flex justify-between text-xs font-semibold">
            <span className="text-zinc-400">⚡ Chỉ tiêu mốc {nextMilestone} ngày vàng</span>
            {daysRemaining > 0 ? (
              <span className="text-cyan-400 font-bold">Còn {daysRemaining} ngày để đổi card {milestoneReward}! 🚀</span>
            ) : (
              <span className="text-emerald-400 font-bold">Đầy rương! Đủ điều kiện nhận {milestoneReward}! 🎉</span>
            )}
          </div>
          
          {/* Progress bar container */}
          <div className="relative w-full h-4 bg-zinc-950 rounded-full overflow-hidden p-0.5 border border-zinc-850">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${Math.min(100, Math.max(8, milestoneProgress))}%` }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="h-full bg-gradient-to-r from-violet-500 via-fuchsia-500 to-cyan-400 rounded-full flex items-center justify-end pr-1.5 min-w-[20px] shadow-[0_0_12px_rgba(139,92,246,0.3)]"
            >
              <div className="w-1.5 h-1.5 bg-white rounded-full animate-ping" />
            </motion.div>
          </div>
          <div className="flex justify-between text-[10px] text-zinc-500 font-mono font-bold">
            <span>Mốc ngày {prevMilestone}</span>
            <span className="text-violet-400">{showPercent}% HOÀN THÀNH</span>
            <span>Mốc {nextMilestone} Ngày</span>
          </div>
        </div>
      </motion.div>

      {/* Revive Tickets Saver Widget */}
      <div className="bg-zinc-950/80 p-5 rounded-3xl border border-zinc-900 shadow-xl">
        <div className="flex justify-between items-center mb-3.5">
          <h4 className="text-xs uppercase font-extrabold tracking-widest text-zinc-400 flex items-center gap-1.5">
            <Ticket className="w-4 h-4 text-violet-400" />
            🎟️ Vé cứu trợ hồi sinh tháng này
          </h4>
          <span className="text-[10px] font-mono font-bold text-zinc-500">Mốc năm 2026</span>
        </div>

        {/* Tickets container */}
        <div className="flex justify-between items-center bg-zinc-900/40 p-4 rounded-2xl border border-zinc-850">
          <div className="flex items-center gap-2">
            {[1, 2, 3].map((index) => {
              const isUsed = index > streakManager.reviveTicketsLeft;
              return (
                <div
                  key={index}
                  className={`relative w-12 h-8 rounded-lg flex items-center justify-center border font-bold transition-all ${
                    isUsed
                      ? "bg-zinc-950/40 border-zinc-900 text-zinc-700 filter saturate-50"
                      : "bg-gradient-to-br from-violet-500/20 to-fuchsia-500/10 border-violet-500/40 text-violet-450 shadow-md shadow-violet-955/20"
                  }`}
                >
                  <Ticket className={`w-4 h-4 ${isUsed ? "text-zinc-800" : "text-violet-400"}`} />
                  {isUsed && (
                    <div className="absolute inset-0 bg-black/60 rounded-xl flex items-center justify-center">
                      <span className="text-[8px] font-black text-rose-500 uppercase tracking-tighter bg-zinc-950 border border-rose-950 px-1 py-0.2 rounded-md scale-90">USED</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
          
          <div className="text-right">
            <div className="text-xs font-bold text-zinc-200">
              Vé còn lại: <span className="text-violet-400 font-black font-mono">{streakManager.reviveTicketsLeft}/3</span> lượt
            </div>
            <div className="text-[9px] text-zinc-500 mt-0.5 font-bold">Kỷ luật tự thân là chìa khóa!</div>
          </div>
        </div>
      </div>

      {/* Main Health Metrics Overview */}
      <div className="space-y-3">
        <h4 className="text-xs uppercase font-extrabold tracking-widest text-zinc-400 px-1">
          🛌 Tổng kết sinh hoạt hôm nay
        </h4>

        {/* 1. Sleep Metric Card */}
        <div
          onClick={() => onNavigate("missions")}
          className="group cursor-pointer bg-zinc-900/30 hover:bg-zinc-900/50 p-4 rounded-2xl border border-zinc-800 hover:border-violet-500/30 transition-all flex items-center justify-between"
          id="metric-sleep"
        >
          <div className="flex items-center gap-3">
            <div className="bg-violet-500/10 p-3 rounded-xl border border-violet-500/20 text-violet-400 group-hover:scale-105 transition-transform">
              <Moon className="w-5 h-5 fill-violet-400/10" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest block">{sleepMission?.title || "GIẤC NGỦ SINH HỌC"}</span>
              <div className="text-zinc-200 font-bold text-sm mt-0.5">
                {!sleepMission?.isMonitored ? (
                  <span className="text-amber-500 text-xs font-semibold">Chưa kích hoạt giám sát</span>
                ) : (
                  <>
                    Bedtime chốt: <span className="text-violet-400 font-mono font-black">{formatSleepTime(sleepMission?.currentValue || 2300)}</span>
                  </>
                )}
              </div>
            </div>
          </div>
          <div className="text-right flex items-center gap-2">
            {sleepMission?.isCompleted ? (
              <span className="text-xs py-1 px-2.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/20 font-semibold">
                Đẹp (Đạt mốc)
              </span>
            ) : !sleepMission?.isMonitored ? (
              <span className="text-xs py-1 px-2.5 rounded-full bg-amber-500/15 text-amber-500 border border-amber-500/20 font-semibold">
                Chờ kích hoạt
              </span>
            ) : (
              <span className="text-xs py-1 px-2.5 rounded-full bg-rose-500/15 text-rose-400 border border-rose-500/20 font-semibold">
                Trễ (Đứt streak)
              </span>
            )}
            <ArrowRight className="w-4 h-4 text-zinc-650 group-hover:text-zinc-400 transition" />
          </div>
        </div>

        {/* 2. Hydration/Water Metric Card */}
        <div
          onClick={() => onNavigate("missions")}
          className="group cursor-pointer bg-zinc-900/30 hover:bg-zinc-900/50 p-4 rounded-2xl border border-zinc-800 hover:border-cyan-500/30 transition-all flex items-center justify-between"
          id="metric-water"
        >
          <div className="flex items-center gap-3">
            <div className="bg-cyan-500/10 p-3 rounded-xl border border-cyan-500/20 text-cyan-400 group-hover:scale-105 transition-transform">
              <Droplet className="w-5 h-5 fill-cyan-400/10" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest block font-sans">{waterMission?.title || "DÒNG CHẢY HEALTHY"}</span>
              <div className="text-zinc-200 font-bold text-sm mt-0.5">
                Đã uống: <span className="text-cyan-400 font-mono font-bold">{waterMission?.currentValue ?? 0}</span> / {waterMission?.targetValue ?? 8} cốc nước
              </div>
            </div>
          </div>
          <div className="text-right flex items-center gap-2">
            {waterMission?.isCompleted ? (
              <span className="text-xs py-1 px-2.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/20 font-semibold flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5" /> Khỏe khoắn
              </span>
            ) : (
              <span className="text-xs py-1 px-2.5 rounded-full bg-cyan-550/15 text-cyan-400 border border-cyan-500/20 font-semibold">
                Thiếu {Math.max(0, (waterMission?.targetValue ?? 8) - (waterMission?.currentValue ?? 0))} cốc
              </span>
            )}
            <ArrowRight className="w-4 h-4 text-zinc-650 group-hover:text-zinc-400 transition" />
          </div>
        </div>

        {/* 3. Sport & Exercise Metric Card */}
        <div
          onClick={() => onNavigate("missions")}
          className="group cursor-pointer bg-zinc-900/30 hover:bg-zinc-900/50 p-4 rounded-2xl border border-zinc-800 hover:border-rose-500/30 transition-all flex items-center justify-between"
          id="metric-exercise"
        >
          <div className="flex items-center gap-3">
            <div className="bg-rose-500/10 p-3 rounded-xl border border-rose-500/20 text-rose-450 group-hover:scale-105 transition-transform">
              <Dumbbell className="w-5 h-5 text-rose-450" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest block">🏃 THỂ DỤC THỂ THAO</span>
              <div className="text-zinc-200 font-bold text-sm mt-0.5">
                {exerciseMission?.isCompleted ? (
                  <span>Đã luyện {exerciseMission.currentValue} phút! 💪</span>
                ) : (
                  <span className="text-rose-400 flex items-center gap-1 text-sm font-semibold">
                    Chưa tập hôm nay! <span className="text-xs animate-ping">⚠️</span>
                  </span>
                )}
              </div>
            </div>
          </div>
          <div className="text-right flex items-center gap-2">
            {exerciseMission?.isCompleted ? (
              <span className="text-xs py-1 px-2.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/20 font-semibold">
                Đã tập
              </span>
            ) : (
              <span className="text-xs py-1 px-2.5 rounded-full bg-zinc-800 text-zinc-400 border border-zinc-800">
                Lười nha
              </span>
            )}
            <ArrowRight className="w-4 h-4 text-zinc-650 group-hover:text-zinc-400 transition" />
          </div>
        </div>
      </div>

      {/* Account Management & Deletion Section */}
      <div className="bg-zinc-900/20 border border-zinc-850 rounded-2xl p-4 space-y-3 shadow-md">
        <div className="flex items-center justify-between gap-3">
          <div>
            <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest block font-sans">QUẢN LÝ HỒ SƠ</span>
            <span className="text-xs font-mono font-bold text-rose-400 mt-0.5 block">
              @{state.currentUser?.username || ""}
            </span>
          </div>
          <button
            onClick={() => setShowDeleteConfirm(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-red-500/20 hover:border-red-500/40 hover:bg-red-500/10 text-[11px] font-bold text-rose-450 transition-all active:scale-95"
            id="btn-delete-current-account"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Xóa tài khoản này
          </button>
        </div>
      </div>

      {/* Interactive Quick Advice Alert */}
      <div className="bg-violet-950/20 border border-violet-500/20 rounded-2xl p-4 flex gap-3 shadow-lg shadow-violet-955/5">
        <Lightbulb className="w-5 h-5 text-violet-400 shrink-0 mt-0.5" />
        <div className="text-xs text-zinc-455 space-y-1">
          <span className="font-extrabold text-violet-300 block uppercase tracking-wider">Lời khuyên thế hệ Gen-Z:</span>
          <span>Thay vì thức đêm cày game hay ép ca, chất lượng giấc ngủ sinh học trước 23:30 quyết định tới 85% năng suất học tập và độ đẹp trai xinh gái của bạn vào ngày mai đấy! Chúc ngủ sung sướng! 😴</span>
        </div>
      </div>

      {/* Current Account Deletion Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/85 backdrop-blur-md">
          <div
            className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 w-full max-w-sm text-center shadow-2xl space-y-4"
            id="modal-current-delete-dashboard"
          >
            <div className="w-12 h-12 rounded-full bg-rose-500/10 text-rose-500 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6 animate-bounce" />
            </div>
            <div className="space-y-1.5">
              <h3 className="text-base font-black uppercase text-zinc-100 tracking-tight font-sans">Xóa Tài Khoản Này?</h3>
              <p className="text-xs text-zinc-400 leading-relaxed font-sans">
                Bạn thực sự muốn xóa vĩnh viễn tài khoản <span className="font-mono font-black text-amber-500">@{state.currentUser?.username}</span> khỏi thiết bị này?
              </p>
              <p className="text-[10px] text-rose-400 italic">
                * Toàn bộ chuỗi Streak và phần thưởng tích lũy sẽ bị xóa hoàn toàn khỏi thiết bị và không thể khôi phục!
              </p>
            </div>
            <div className="flex gap-2.5 pt-2">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="flex-1 py-2.5 bg-zinc-800 hover:bg-zinc-700 transition font-bold rounded-xl text-xs text-zinc-300 active:scale-95 uppercase tracking-wide"
              >
                HỦY BỎ
              </button>
              <button
                onClick={() => {
                  setShowDeleteConfirm(false);
                  onDeleteAccount();
                }}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 transition font-black rounded-xl text-xs text-white active:scale-95 uppercase tracking-wide"
                id="btn-confirm-delete-dashboard"
              >
                XÁC NHẬN XÓA
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
