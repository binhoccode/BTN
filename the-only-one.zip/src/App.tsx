/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { AppState, MissionType, Reward } from "./types";
import { getInitialState, saveState, createStateForUser, AccountCredentials, loadRegisteredAccounts, saveRegisteredAccounts } from "./utils";
import Dashboard from "./components/Dashboard";
import Missions from "./components/Missions";
import RewardShop from "./components/RewardShop";
import HistoryStats from "./components/HistoryStats";
import AuthScreen from "./components/AuthScreen";
import { Home, ClipboardList, Gift, BarChart3, Settings, Flame, ShieldAlert, Heart } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function App() {


  // Initialize application state matching the defaults
  const [state, setState] = useState<AppState>(getInitialState);
  const [activeTab, setActiveTab] = useState<string>("home");

  // Sync state changes with localStorage for client-side persistence
  useEffect(() => {
    saveState(state);
    if (state.currentUser?.username) {
      localStorage.setItem(`the_only_one_user_state_${state.currentUser.username}`, JSON.stringify(state));
    }
  }, [state]);

  // Automatic Daily Reset when a new actual calendar day is detected
  useEffect(() => {
    if (!state.currentUser?.username) return;

    // Get current local date string (YYYY-MM-DD)
    const offset = new Date().getTimezoneOffset();
    const localDate = new Date(Date.now() - offset * 60 * 1000);
    const todayStr = localDate.toISOString().split("T")[0];

    const lastDate = state.user?.lastActiveDate;

    if (!lastDate) {
      setState(prev => ({
        ...prev,
        user: {
          ...prev.user,
          lastActiveDate: todayStr
        }
      }));
      return;
    }

    if (lastDate !== todayStr) {
      setState(prev => {
        // Double check within state mutation to prevent concurrency loops
        if (prev.user.lastActiveDate === todayStr) return prev;

        // Roll over streak logic based on previous day status
        let nextStreak = prev.streakManager.currentStreak;
        let nextIsBroken = prev.streakManager.isBroken;
        const nextTickets = prev.streakManager.reviveTicketsLeft;

        // Check if yesterday's missions were completed and confirmed
        const prevMissionsAllDone = prev.missions.every(m => m.isCompleted);
        const prevConfirmed = prev.hasConfirmedToday;

        if (prevConfirmed && prevMissionsAllDone) {
          nextStreak += 1;
          nextIsBroken = false;
        } else {
          // New accounts (highestStreak === 0) do not suffer from broken streaks
          nextIsBroken = prev.user.highestStreak > 0;
          if (nextTickets <= 0) {
            nextStreak = 0;
          }
        }

        // Prepare fresh missions for the new day
        const freshMissions = prev.missions.map(m => {
          if (m.missionType === MissionType.SLEEP) {
            return { ...m, isCompleted: false, currentValue: 2345, isMonitored: false }; // default late bedtime till monitored
          } else if (m.missionType === MissionType.EAT) {
            return { ...m, isCompleted: false, currentValue: 0 }; // fresh water
          } else {
            return { ...m, isCompleted: false, currentValue: 0 }; // fresh exercise
          }
        });

        return {
          ...prev,
          user: {
            ...prev.user,
            currentStreak: nextStreak,
            highestStreak: Math.max(prev.user.highestStreak, nextStreak),
            lastActiveDate: todayStr
          },
          streakManager: {
            ...prev.streakManager,
            currentStreak: nextStreak,
            isBroken: nextIsBroken,
            reviveTicketsLeft: nextTickets
          },
          missions: freshMissions,
          hasConfirmedToday: false
        };
      });
    }
  }, [state.currentUser?.username, state.user?.lastActiveDate]);

  // Handle generalized state updating from simulations
  const handleModifyState = (modifyFn: (prev: AppState) => AppState) => {
    setState(prev => modifyFn(prev));
  };

  const handleLoginSuccess = (credentials: AccountCredentials, isNew: boolean) => {
    // Attempt to load the user's independent state from localStorage
    const storageKey = `the_only_one_user_state_${credentials.username}`;
    const saved = localStorage.getItem(storageKey);
    let loadedState: AppState;

    if (saved && !isNew) {
      try {
        loadedState = JSON.parse(saved);
        // Ensure proper user identification
        loadedState.currentUser = { username: credentials.username, email: credentials.email };
      } catch (e) {
        loadedState = createStateForUser(
          credentials.username,
          credentials.fullName,
          credentials.initialStreak,
          credentials.email
        );
      }
    } else {
      loadedState = createStateForUser(
        credentials.username,
        credentials.fullName,
        credentials.initialStreak,
        credentials.email
      );
    }
    setState(loadedState);
    setActiveTab("home");
  };

  const handleLogout = () => {
    // Clear active session to view auth portal
    setState(prev => ({
      ...prev,
      currentUser: null
    }));
  };

  const handleDeleteCurrentAccount = () => {
    if (!state.currentUser?.username) return;
    const usernameToDelete = state.currentUser.username;

    // 1. Remove from accounts database list
    const registered = loadRegisteredAccounts();
    const updated = { ...registered };
    delete updated[usernameToDelete];
    saveRegisteredAccounts(updated);

    // 2. Clear specialized user state cache
    localStorage.removeItem(`the_only_one_user_state_${usernameToDelete}`);

    // 3. Clear current active state and log out
    setState(prev => ({
      ...prev,
      currentUser: null
    }));
  };

  // Callback to update mission metrics
  const handleUpdateMissionValue = (missionType: MissionType, value: number, isMonitoredUpdate?: boolean) => {
    setState(prev => {
      const updatedMissions = prev.missions.map(m => {
        if (m.missionType === missionType) {
          let completes = false;
          const currentMonitored = isMonitoredUpdate !== undefined ? isMonitoredUpdate : m.isMonitored;
          // Check custom completeness conditions based on type
          if (missionType === MissionType.SLEEP) {
            completes = !!currentMonitored && value >= 1200 && value <= 2330; // Slept before or exactly at 23:30 threshold (12:00 to 23:30) after activating monitoring
          } else if (missionType === MissionType.EAT) {
            completes = value >= m.targetValue; // Drank >= 8 cups of water
          } else if (missionType === MissionType.EXERCISE) {
            completes = value >= m.targetValue; // Exercised >= 5 mins
          }
          return {
            ...m,
            currentValue: value,
            isCompleted: completes,
            isMonitored: currentMonitored
          };
        }
        return m;
      });

      return {
        ...prev,
        missions: updatedMissions
      };
    });
  };

  // Callback to confirm day completion and secure streak!
  const handleConfirmDailyMissions = () => {
    setState(prev => {
      // Complete today's check-in
      const isAlreadyActive = !prev.streakManager.isBroken;
      const prevStreak = prev.streakManager.currentStreak;
      // If today is successfully saved, streak goes up
      const nextStreak = prevStreak + 1;

      return {
        ...prev,
        user: {
          ...prev.user,
          currentStreak: nextStreak,
          highestStreak: Math.max(prev.user.highestStreak, nextStreak)
        },
        streakManager: {
          ...prev.streakManager,
          currentStreak: nextStreak,
          isBroken: false
        },
        hasConfirmedToday: true
      };
    });
  };

  // Callback to claim rewards from milestone vouchers
  const handleClaimReward = (rewardId: string, telco: string, pin: string, serial: string) => {
    setState(prev => {
      const updatedRewards = prev.rewards.map(r => {
        if (r.rewardId === rewardId) {
          return {
            ...r,
            isClaimed: true,
            claimTelco: telco,
            claimCode: pin,
            claimSerial: serial,
            claimedAt: new Date().toISOString()
          };
        }
        return r;
      });

      return {
        ...prev,
        rewards: updatedRewards
      };
    });
  };

  // Callback to watches ad and recovers broken streak with saved tickets
  const handleReviveStreak = () => {
    setState(prev => {
      // Consume 1 ticket
      const remainingTickets = Math.max(0, prev.streakManager.reviveTicketsLeft - 1);
      
      // Keep existing streak, restore broken trigger to false
      return {
        ...prev,
        streakManager: {
          ...prev.streakManager,
          isBroken: false,
          reviveTicketsLeft: remainingTickets
        }
      };
    });
  };

  // Render the currently selected tab
  const renderContent = () => {
    switch (activeTab) {
      case "home":
        return (
          <Dashboard
            state={state}
            onNavigate={setActiveTab}
            onLogout={handleLogout}
            onDeleteAccount={handleDeleteCurrentAccount}
          />
        );
      case "missions":
        return (
          <Missions
            state={state}
            onNavigate={setActiveTab}
            onUpdateMissionValue={handleUpdateMissionValue}
            onConfirmDailyMissions={handleConfirmDailyMissions}
          />
        );
      case "rewards":
        return (
          <RewardShop
            state={state}
            onNavigate={setActiveTab}
            onClaimReward={handleClaimReward}
            onReviveStreak={handleReviveStreak}
          />
        );
      case "stats":
        return <HistoryStats state={state} />;
      default:
        return (
          <Dashboard
            state={state}
            onNavigate={setActiveTab}
            onLogout={handleLogout}
            onDeleteAccount={handleDeleteCurrentAccount}
          />
        );
    }
  };

  if (!state.currentUser) {
    return <AuthScreen onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans antialiased selection:bg-amber-500 selection:text-zinc-950">
      
      {/* Decorative top ambient bar */}
      <div className="w-full h-1 bg-gradient-to-r from-amber-500 via-orange-500 to-red-600" />

      {/* Main Container */}
      <main className="flex-1 w-full max-w-lg mx-auto px-4 pt-6 pb-28">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.15, ease: "easeInOut" }}
          >
            {renderContent()}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Persistent Bottom Tabbed Footer matching the WIREFRAME */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-zinc-900/90 backdrop-blur-xl border-t border-zinc-800/80 shadow-2xl py-2 px-1">
        <div className="max-w-lg mx-auto grid grid-cols-4 gap-1">
          {/* TAB 1: HOME */}
          <button
            onClick={() => setActiveTab("home")}
            className={`flex flex-col items-center justify-center py-1.5 rounded-xl transition ${
              activeTab === "home"
                ? "text-amber-500 bg-amber-500/5 font-bold"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
            id="tab-home"
          >
            <Home className="w-5 h-5 mb-1" />
            <span className="text-[10px] font-medium tracking-tight">Home</span>
          </button>

          {/* TAB 2: MISSIONS */}
          <button
            onClick={() => setActiveTab("missions")}
            className={`flex flex-col items-center justify-center py-1.5 rounded-xl transition ${
              activeTab === "missions"
                ? "text-amber-500 bg-amber-500/5 font-bold"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
            id="tab-missions"
          >
            <div className="relative">
              <ClipboardList className="w-5 h-5 mb-1" />
              {!state.hasConfirmedToday && (
                <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full animate-bounce" />
              )}
            </div>
            <span className="text-[10px] font-medium tracking-tight">Nhiệm Vụ</span>
          </button>

          {/* TAB 3: REWARD SHOP */}
          <button
            onClick={() => setActiveTab("rewards")}
            className={`flex flex-col items-center justify-center py-1.5 rounded-xl transition ${
              activeTab === "rewards"
                ? "text-amber-500 bg-amber-500/5 font-bold"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
            id="tab-rewards"
          >
            <Gift className="w-5 h-5 mb-1" />
            <span className="text-[10px] font-medium tracking-tight">Đổi Quà</span>
          </button>

          {/* TAB 4: HISTORY STATS */}
          <button
            onClick={() => setActiveTab("stats")}
            className={`flex flex-col items-center justify-center py-1.5 rounded-xl transition ${
              activeTab === "stats"
                ? "text-amber-500 bg-amber-500/5 font-bold"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
            id="tab-stats"
          >
            <BarChart3 className="w-5 h-5 mb-1" />
            <span className="text-[10px] font-medium tracking-tight">Thống Kê</span>
          </button>
        </div>
      </nav>

    </div>
  );
}
