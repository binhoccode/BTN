/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AppState, Mission, MissionType, Reward, StreakManager, User } from "./types";

// Key for Local Storage persistence of active applet state
const LOCAL_STORAGE_KEY = "the_only_one_app_state";

// Key to store list of registered accounts locally
export const ACCOUNTS_STORAGE_KEY = "the_only_one_users_list";

export interface AccountCredentials {
  username: string;
  fullName: string;
  email: string;
  initialStreak: number;
}

// Generate a random VN card pin
export function generatePhoneCardCode(carrier: string): { pin: string; serial: string } {
  const genDigits = (len: number) => {
    let result = "";
    for (let i = 0; i < len; i++) {
      result += Math.floor(Math.random() * 10).toString();
    }
    return result;
  };
  
  return {
    pin: genDigits(13),
    serial: genDigits(11)
  };
}

// Create a state shell for any user
export function createStateForUser(username: string, fullName: string, initialStreak: number, email: string): AppState {
  const initialRewards: Reward[] = [
    {
      rewardId: "r50",
      rewardMilestone: 50,
      rewardValue: 10000,
      isClaimed: false
    },
    {
      rewardId: "r100",
      rewardMilestone: 100,
      rewardValue: 50000,
      isClaimed: false
    },
    {
      rewardId: "r200",
      rewardMilestone: 200,
      rewardValue: 100000,
      isClaimed: false
    },
    {
      rewardId: "r300",
      rewardMilestone: 300,
      rewardValue: 150000,
      isClaimed: false
    },
    {
      rewardId: "r450",
      rewardMilestone: 400,
      rewardValue: 200000,
      isClaimed: false
    }
  ];

  const userObj: User = {
    userId: `sv_${username}`,
    userName: fullName,
    currentStreak: initialStreak,
    highestStreak: initialStreak,
    lastActiveDate: new Date().toISOString().split("T")[0]
  };

  const missionsObj: Mission[] = [
    {
      missionId: "m_sleep",
      missionType: MissionType.SLEEP,
      title: "GIẤC NGỦ SINH HỌC",
      description: "Đi ngủ trước 23:30 tối qua để giữ mốc sinh học nhịp nhàng.",
      isCompleted: false,
      currentValue: 2345,
      targetValue: 2330,
      isMonitored: false
    },
    {
      missionId: "m_water",
      missionType: MissionType.EAT,
      title: "UỐNG ĐỦ NƯỚC ĐI BẠN ƠI!!!",
      description: "Uống đủ 2L nước mát (khoảng 8 cốc nước lọc mỗi ngày).",
      isCompleted: false,
      currentValue: initialStreak > 0 ? 5 : 0,
      targetValue: 8
    },
    {
      missionId: "m_exercise",
      missionType: MissionType.EXERCISE,
      title: "ĐÁNH BẠI ĐAU VAI GÁY",
      description: "Thực hiện bài tập giãn cơ cơ bản hoặc hít đất chống mỏi 5 phút.",
      isCompleted: false,
      currentValue: 0,
      targetValue: 5
    }
  ];

  const streakManagerObj: StreakManager = {
    currentStreak: initialStreak,
    isBroken: false,
    reviveTicketsLeft: initialStreak > 0 ? 2 : 3,
    lastReviveMonth: new Date().getMonth()
  };

  return {
    user: userObj,
    missions: missionsObj,
    streakManager: streakManagerObj,
    rewards: initialRewards,
    hasConfirmedToday: false,
    currentUser: {
      username,
      email
    }
  };
}

// Local accounts directory loader
export function loadRegisteredAccounts(): Record<string, AccountCredentials> {
  if (typeof window !== "undefined") {
    const saved = localStorage.getItem(ACCOUNTS_STORAGE_KEY);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Error loaded registered users directory:", e);
      }
    }
  }
  
  // Return empty registry so the user has to register their own account
  return {};
}

export function saveRegisteredAccounts(accounts: Record<string, AccountCredentials>): void {
  if (typeof window !== "undefined") {
    localStorage.setItem(ACCOUNTS_STORAGE_KEY, JSON.stringify(accounts));
  }
}

// Retrieve dynamic AppState
export function getInitialState(): AppState {
  if (typeof window !== "undefined") {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.user && parsed.missions && parsed.streakManager && parsed.rewards) {
          // Rename missions inside saved states to make sure existing users obtain updated names immediately!
          parsed.missions = parsed.missions.map((m: Mission) => {
            if (m.missionType === MissionType.SLEEP) {
              return { ...m, title: "GIẤC NGỦ SINH HỌC" };
            }
            if (m.missionType === MissionType.EAT) {
              return { ...m, title: "Uống ĐỦ NƯỚC ĐI BẠN ƠI!!!" };
            }
            return m;
          });
          // Ensure we start with the register/login screen first on startup
          parsed.currentUser = null;
          return parsed;
        }
      } catch (e) {
        console.error("Error reading state from localStorage:", e);
      }
    }
  }

  // Fallback to empty default state (no user logged in initially)
  const defaultState: AppState = {
    user: {
      userId: "",
      userName: "",
      currentStreak: 0,
      highestStreak: 0,
      lastActiveDate: new Date().toISOString().split("T")[0]
    },
    missions: [
      {
        missionId: "m_sleep",
        missionType: MissionType.SLEEP,
        title: "GIẤC NGỦ SINH HỌC",
        description: "Đi ngủ trước 23:30 tối qua để giữ mốc sinh học nhịp nhàng.",
        isCompleted: false,
        currentValue: 2345,
        targetValue: 2330,
        isMonitored: false
      },
      {
        missionId: "m_water",
        missionType: MissionType.EAT,
        title: "Uống ĐỦ NƯỚC ĐI BẠN ƠI!!!",
        description: "Uống đủ 2L nước mát (khoảng 8 cốc nước lọc mỗi ngày).",
        isCompleted: false,
        currentValue: 0,
        targetValue: 8
      },
      {
        missionId: "m_exercise",
        missionType: MissionType.EXERCISE,
        title: "ĐÁNH BẠI ĐAU VAI GÁY",
        description: "Thực hiện bài tập giãn cơ cơ bản hoặc hít đất chống mỏi 5 phút.",
        isCompleted: false,
        currentValue: 0,
        targetValue: 5
      }
    ],
    streakManager: {
      currentStreak: 0,
      isBroken: false,
      reviveTicketsLeft: 3,
      lastReviveMonth: new Date().getMonth()
    },
    rewards: [
      {
        rewardId: "r50",
        rewardMilestone: 50,
        rewardValue: 10000,
        isClaimed: false
      },
      {
        rewardId: "r100",
        rewardMilestone: 100,
        rewardValue: 50000,
        isClaimed: false
      },
      {
        rewardId: "r200",
        rewardMilestone: 200,
        rewardValue: 100000,
        isClaimed: false
      },
      {
        rewardId: "r300",
        rewardMilestone: 300,
        rewardValue: 150000,
        isClaimed: false
      },
      {
        rewardId: "r450",
        rewardMilestone: 400,
        rewardValue: 200000,
        isClaimed: false
      }
    ],
    hasConfirmedToday: false,
    currentUser: null
  };
  return defaultState;
}

export function saveState(state: AppState): void {
  if (typeof window !== "undefined") {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(state));
  }
}
