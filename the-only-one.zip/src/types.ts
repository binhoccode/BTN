/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface User {
  userId: string;
  userName: string;
  currentStreak: number;
  highestStreak: number;
  lastActiveDate: string; // Formatting: YYYY-MM-DD
}

export enum MissionType {
  SLEEP = "SLEEP",
  EAT = "EAT",
  EXERCISE = "EXERCISE"
}

export interface Mission {
  missionId: string;
  missionType: MissionType;
  title: string;
  description: string;
  isCompleted: boolean;
  currentValue: number; // Sleep minutes, water cups, or workout minutes
  targetValue: number;
  isMonitored?: boolean;
}

export interface StreakManager {
  currentStreak: number;
  isBroken: boolean;
  reviveTicketsLeft: number; // Defaults to 3 per month
  lastReviveMonth: number; // 0-11 month representation
}

export interface Reward {
  rewardId: string;
  rewardMilestone: number; // 50, 100, 200...
  rewardValue: number; // 10000, 50000...
  isClaimed: boolean;
  claimCode?: string; // Telco code pin block (Vietnamese carriers)
  claimSerial?: string; // Serial sequence
  claimTelco?: string; // Carrier name
  claimedAt?: string; // ISO date string
}

export interface AppState {
  user: User;
  missions: Mission[];
  streakManager: StreakManager;
  rewards: Reward[];
  hasConfirmedToday: boolean;
  currentUser?: {
    username: string;
    email: string;
  } | null;
}
